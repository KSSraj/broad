$(function () {

    $("#verifyEmailForm").on('submit', function (e) {
        e.preventDefault();

        $("#verifyotpspinner").removeClass('d-none');
        $("#sendOtp").prop('disabled', true);

        // Clear any previous error messages        
        $('.error-email').text('');
        let email = $("#email").val();
        $("#otpemail").val(email);
        $("#remail").val(email);

        // Get form data
        let formData = {
            email: $('#email').val(),
        };

        $.ajax({
            url: '/send-otp',
            type: 'POST',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'), // Include CSRF token if necessary
            },
            success: function (response) {
                alert(response.message);

                $("#verifyotpspinner").addClass('d-none');
                $("#sendOtp").prop('disabled', false);

                $("#emailtoverify").text(formData.email);

                $('#verifyEmailForm').hide();
                $('#otpForm').show();

                startTimer();
            },
            error: function (xhr) {

                alert(xhr.responseJSON.message);

                $("#verifyotpspinner").addClass('d-none');
                $("#sendOtp").prop('disabled', false);

                if (xhr.status === 422) {
                    // Validation errors
                    let errors = xhr.responseJSON.errors;
                    if (errors.email) {
                        $('.error-email').text(errors.email[0]);
                    }
                } else {
                    alert('An error occurred. Please try again.');
                }
            },
        });

    })


    // Handle OTP form submission
    $('#otpForm').on('submit', function (e) {
        e.preventDefault();
        $("#submitotpspinner").removeClass('d-none');
        // Clear any previous error messages
        $('.error-otp').text('');

        // Collect OTP data
        let otp = getOtpValues();
        let formData = {
            email: $("#otpemail").val(),
            otp: otp,
        };

        // Send AJAX POST request
        $.ajax({
            url: '/verify-otp', // Endpoint for OTP verification
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'), // Include CSRF token if necessary
            },
            data: formData,
            success: function (response) {
                // OTP verified successfully, show the password form 
                $("#submitotpspinner").addClass('d-none');
                $('#setPasswordFrom').show();
                $('#otpForm').hide();  // Hide the OTP form              
            },
            error: function (xhr) {
                $("#submitotpspinner").addClass('d-none');
                if (xhr.status === 422) {
                    // Handle validation errors
                    let errors = xhr.responseJSON.errors;
                    if (errors.otp) {
                        $('.error-otp').text(errors.otp[0]);
                    }
                } else {
                    //alert('Invalid OTP. Please try again.');
                    $('.error-otp').text("Invalid OTP. Please try again");
                }
            },
        });
    });


    // Handle set password form submit
    $('#setPasswordFrom').on('submit', function (e) {
        e.preventDefault(); // Prevent default form submission   

        $("#registerspinner").removeClass('d-none');

        let password = $('#password').val();
        let password_confirmation = $('#password_confirmation').val();
        let name = $('#name').val();
        let email = $("#email").val();

        if (name == "" || name == null) {
            alert('Enter name.');
            return;
        }
        if (email == "" || email == null) {
            alert('Enter email.');
            return;
        }

        // Check if password and confirmation match
        if (password !== password_confirmation) {
            alert('Passwords do not match. Please try again.');
            return;
        }

        // Send the password to the server to set it for the user
        $.ajax({
            url: '/register',  // Endpoint to set the password
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'), // Include CSRF token if necessary
            },
            data: {
                password: password,  // New password 
                password_confirmation: password_confirmation,
                name: name,
                email: email
            },
            success: function (response) {
                $("#registerspinner").addClass('d-none');
                if (response) {
                    window.location.href = '/profile/step/1';  // Redirect to login page
                } else {
                    alert('Something went wrong. Please try again.');
                }
            },
            error: function (xhr) {
                $("#registerspinner").addClass('d-none');
                if (xhr.status === 422) {
                    // Handle validation errors
                    let errors = xhr.responseJSON.errors;
                    if (errors.password) {
                        $('.error-password').text(errors.otp[0]);
                    }
                    if (errors.email) {
                        $('.error-email').text(errors.email[0]);
                    }
                } else {
                    $('.error-password').text("Invalid password. Please try again");
                }

            }
        });
    });

    function getOtpValues() {
        let otpValues = [];

        // Select all input fields with name="otp[]"
        $('input[name="otp[]"]').each(function () {
            otpValues.push($(this).val()); // Add each value to the otpValues array
        });

        // Return the OTP values as a string or array
        return otpValues.join('');  // Join the array into a single string (optional)
    }
});

// verify otp
function moveToNext(current, nextFieldID) {
    current.value = current.value.trim();
    if (!isNaN(current.value)) {
        if (current.value.length >= 1 && nextFieldID) {
            document.getElementById(nextFieldID).focus();
        }
    } else {
        // Optionally, you can clear the invalid input or give feedback
        current.value = '';  // Clear invalid input
    }
}
function moveToPrevious(event, currentFieldID, prevFieldID) {
    if (event.key === 'Backspace' && document.getElementById(currentFieldID).value === '' && prevFieldID) {
        document.getElementById(prevFieldID).focus();
    }
}

let setTime = 60;
let timeLeft = setTime;
let timerInterval;

function resendOtp() {
    timeLeft = setTime;
    startTimer();
}

function startTimer() {
    if (timerInterval) return; // Prevent starting multiple timers

    timerInterval = setInterval(function () {
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            document.getElementById("timer").innerHTML = timeLeft;
        } else {
            document.getElementById("timer").innerHTML = timeLeft;
            timeLeft--;
        }
    }, 1000); // 1000ms = 1 second
}
//startTimer();


