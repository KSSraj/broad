$(document).ready(function () {

    // Submit form
    $('#add-attributes-form').on('submit', function (e) {
        e.preventDefault();

        // Collect data        
        const attributes = [
            { "attribute_key": "Height", "attribute_value": $('#height').val() },
            { "attribute_key": "Weight", "attribute_value": $('#weight').val() },
            { "attribute_key": "Build", "attribute_value": $('#build').val() },
            { "attribute_key": "Hair", "attribute_value": $('#hair').val() },
            { "attribute_key": "Eyes", "attribute_value": $('#eyes').val() },
            { "attribute_key": "Skin", "attribute_value": $('#skin').val() },
        ];


        // Send AJAX request
        $.ajax({
            url: '/attributes', // Adjust this to your API endpoint
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'), // Include CSRF token if necessary
            },
            data: {
                attributes: attributes,
                profile_id: $("#profile_id").val()
            },
            success: function (response) {
                if (response.success) {
                    Swal.fire('Success!', response.message, 'success');
                } else {
                    Swal.fire('Error!', response.message, 'error');
                }
            },
            error: function (xhr) {
                Swal.fire('Error!', 'Something went wrong. Please try again.', 'error');
            },
        });
    });

    // update profile desctiption
    // Submit form
    // $('#profileDescription').on('submit', function (e) {
    //     e.preventDefault();
    //     // Collect data        
    //     let profileDescription = $("#description").val();

    //     // Send AJAX request
    //     $.ajax({
    //         url: '/profile/update', // Adjust this to your API endpoint
    //         method: 'PUT',
    //         headers: {
    //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'), // Include CSRF token if necessary
    //         },
    //         data: {
    //             description: profileDescription,
    //             profile_id: $("#profile_id").val()
    //         },
    //         success: function (response) {
    //             if (response.success) {
    //                 Swal.fire('Success!', response.message, 'success');
    //                 $(".btn-close").trigger("click");
    //             } else {
    //                 Swal.fire('Error!', response.message, 'error');
    //             }
    //         },
    //         error: function (xhr) {
    //             Swal.fire('Error!', 'Something went wrong. Please try again.', 'error');
    //         },
    //     });
    // });

    // $('form[name="profileExperience"]').on('submit', function (e) {
    //     e.preventDefault();

    //     // Collect data               
    //     // Send AJAX request
    //     $.ajax({
    //         url: '/profile/experience', // Adjust this to your API endpoint
    //         method: $(this).attr("method"),
    //         headers: {
    //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'), // Include CSRF token if necessary
    //         },            
    //         data: {
    //             experience: $(this).serialize(),
    //             profile_id: $("#profile_id").val(),
    //             experience_id: $("input[name='experience_id']").val(),
    //         },
    //         success: function (response) {
    //             if (response.success) {
    //                 Swal.fire('Success!', response.message, 'success');
    //                 $(".btn-close").trigger("click");
    //             } else {
    //                 Swal.fire('Error!', response.message, 'error');
    //             }
    //         },
    //         error: function (xhr) {
    //             Swal.fire('Error!', 'Something went wrong. Please try again.', 'error');
    //         },
    //     });
    // });
});
