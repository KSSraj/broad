$(function () {

    $("#email,#password").on("focusout", function () {
        loginClientFormValidation();
    });

    $("#email").on("focus", function () {
        $('#email').removeClass(["border border-danger border-2"]);
        $('#email').removeClass(["border border-success border-2"]);
        $('#email').addClass(["border border-warning border-2"]);
    });

    $("#password").on("focus", function () {
        $('#password').removeClass(["border border-danger border-2"]);
        $('#password').removeClass(["border border-success border-2"]);
        $('#password').addClass(["border border-warning border-2"]);
    });

    function loginClientFormValidation() {

        let isValid = true;
        let email = $('#email').val();
        let password = $('#password').val();

        // Email validation
        if (!email || !validateEmail(email)) {
            $('#email').addClass(["border border-danger border-2"]);
            isValid = false;
        } else {
            $('#email').removeClass(["border border-danger border-2"]);
            $('#email').removeClass(["border border-warning border-2"]);
            $('#email').addClass(["border border-success border-2"]);
        }

        // Password validation
        if (!password) {
            $('#password').addClass(["border border-danger border-2"]);
            isValid = false;
        } else {
            $('#password').removeClass(["border border-danger border-2"]);
            $('#password').removeClass(["border border-warning border-2"]);
            $('#password').addClass(["border border-success border-2"]);
        }

        if (!isValid) {
            return;
        }
    }

    $('#loginForm').on('submit', function (e) {
        e.preventDefault();

        // Clear previous error messages
        $('#errorMessages').addClass('d-none').html('');

        $("#loginspinner").removeClass('d-none');
        // CSRF token setup
        const token = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
            url: $(this).attr("action"),
            method: "POST",
            data: {
                email: $('#email').val(),
                password: $('#password').val(),
                _token: token,
            },
            success: function (response) {
                if (response.success) {
                    //alert('Login successful!');
                    $("#loginspinner").addClass('d-none');
                    window.location.href = response.redirect;
                }
            },
            error: function (xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    let errorHtml = '';
                    $.each(errors, function (key, value) {
                        errorHtml += `<p>${value}</p>`;
                    });
                    $("#loginspinner").addClass('d-none');
                    $('#errorMessages').removeClass('d-none').html(errorHtml);
                } else {
                    alert('An unexpected error occurred.');
                }
            }
        });
    });

    function validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    const passwordInput = document.getElementById('password');
    const togglePassword = document.getElementById('togglePassword');
    const togglePasswordIcon = document.getElementById('togglePasswordIcon');
    togglePassword.addEventListener('click', function () {
        // Toggle the type attribute
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);

        // Toggle the icon
        togglePasswordIcon.classList.toggle('bi-eye-fill');
        togglePasswordIcon.classList.toggle('bi-eye-slash-fill');
    });
});