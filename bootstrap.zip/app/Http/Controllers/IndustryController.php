<?php
namespace App\Http\Controllers;

use App\Models\ProfileIndustry;

class IndustryController extends Controller
{

    public function selectIndustries()
    {
        $industries = ProfileIndustry::all();
        return view("profile.my_industry", compact("industries"));
    }

}
