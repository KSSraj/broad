<?php
namespace App\Http\Controllers;

use App\Models\ProfileType;

class ProfileTypeController extends Controller
{
    public function getProfileTypes()
    {
        $profileTypes = ProfileType::all();
        return response()->json($profileTypes);
    }
}
