<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use App\Models\Profile;
use App\Models\ProfileHighlight;
use Illuminate\Support\Facades\Validator;
class ProfileHighlightController extends Controller
{
    //
  
    public function highlights($profileId)
    {
        $highlights = ProfileHighlight::where('profile_id', $profileId)
            ->orderBy('year', 'desc')            
            ->get();
        return response()->json($highlights);
    }
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [            
            "description" => "string|required",            
            "year" => "integer|required",
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {

            $profile = Profile::findOrFail($request->profile_id);
            $highlight = new ProfileHighlight($request->all());
            $profile->highlights()->save($highlight);

            return response()->json($highlight);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }

    public function update(Request $request, ProfileHighlight $highlight)
    {
        // dd($experience);
        $validator = Validator::make($request->all(), [            
            "description" => "string|required",         
            "year" => "integer|required",
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
                   
            $highlight->update($request->all());
            return response()->json($highlight);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }
    public function destroy($eduId)
    {
        $highlight = ProfileHighlight::findOrFail($eduId);

        $highlight->forceDelete();

        return response()->json([
            'success' => true,
            'message' => 'Education deleted successfully',
        ], 200);
    }

}
