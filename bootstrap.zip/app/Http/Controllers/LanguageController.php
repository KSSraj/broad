<?php
namespace App\Http\Controllers;

use App\Models\IndustryLanguage;
use Illuminate\Http\Request;
use App\Models\Profile;
class LanguageController extends Controller
{
    public function getLanguages()
    {
        $languages = IndustryLanguage::all();
        return response()->json($languages);
    }

    public function show($id)
    {
        $languages = Profile::findOrFail($id)->languages;
        return response()->json($languages);
    }

    public function store(Request $request)
    {        
        $validated = $request->validate([
            'profile_id' => 'required|exists:profiles,id',
            'languages' => 'required|array',
            'languages.*' => 'exists:industry_languages,id',         
        ]);
       
        $profile = Profile::findOrFail($request->input("profile_id"));
        $profileLanguages =  $profile->languages()->sync($request->languages);        
        return response()->json($profile->languages, 201);
    }

    public function destroy($id)
    {
        // $socialLink = SocialLink::findOrFail($id);
        // $socialLink->delete();

        // return response()->json(null, 204);
    }
}
