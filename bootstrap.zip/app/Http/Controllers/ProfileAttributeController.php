<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use App\Models\ProfileAttribute;
use App\Models\Profile;
use Illuminate\Support\Facades\Validator;
class ProfileAttributeController extends Controller
{
    //

    public function index($profileId)
    {
        $attributes = ProfileAttribute::where('profile_id', $profileId)->get();
        return response()->json($attributes);
    }

    public function store(Request $request)
    {
        //dd($request->all());
        // $validator = Validator::make($request->all(), [
        //     'attributes.*.attribute_key' => 'required|string',
        //     'attributes.*.attribute_value' => 'nullable|string',
        // ]);

        // if ($validator->fails()) {
        //     return response()->json(['errors' => $validator->errors()], 422);
        // }

        try {
            $attributes = $request->except("profile_id");
            $profile = Profile::findOrFail($request->profile_id);

            foreach ($attributes as $key => $value) {
                $profile->attributes()->updateOrCreate(
                    ['attribute_key' => $key], // Match by key
                    ['attribute_value' => $value] // Update or insert value
                );
            }

            return response()->json($profile->attributes);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }


    public function destroy($profileId, $attributeKey)
    {
        $profile = Profile::findOrFail($profileId);

        $profile->attributes()->where('attribute_key', $attributeKey)->delete();

        return response()->json([
            'success' => true,
            'message' => 'Profile attribute deleted successfully',
        ], 200);
    }

}
