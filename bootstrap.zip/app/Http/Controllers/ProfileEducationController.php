<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use App\Models\Profile;
use App\Models\ProfileEducation;
use Illuminate\Support\Facades\Validator;
class ProfileEducationController extends Controller
{
    //

    public function index($profileId)
    {       
    }

    public function educations($profileId)
    {
        $educations = ProfileEducation::where('profile_id', $profileId)
            ->orderBy('year', 'desc')            
            ->get();
        return response()->json($educations);
    }
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [            
            "description" => "string|required",            
            "year" => "integer|required",
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {

            $profile = Profile::findOrFail($request->profile_id);
            $education = new ProfileEducation($request->all());
            $profile->educations()->save($education);

            return response()->json([
                'message' => 'Experience added successfully!',
                'education' => $education,
            ]);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }

    public function update(Request $request, ProfileEducation $education)
    {
        // dd($experience);
        $validator = Validator::make($request->all(), [            
            "description" => "string|required",         
            "year" => "integer|required",
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
                   
            $education->update($request->all());
            return response()->json([
                'message' => 'Education updated successfully!',
                'education' => $education,
            ]);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }
    public function destroy($eduId)
    {
        $education = ProfileEducation::findOrFail($eduId);

        $education->forceDelete();

        return response()->json([
            'success' => true,
            'message' => 'Education deleted successfully',
        ], 200);
    }

}
