<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\Department;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\View\View;
use Illuminate\Support\Facades\Validator;
use App\Models\Profile;
use App\Models\ProfileIndustry;
use App\Models\IndustryLanguage;
use App\Models\ProfileType;
use App\Models\User;
use Illuminate\Support\Facades\Log;
class ProfileController extends Controller
{
    /**
     * Display the user's profile form.
     */
    public function edit(Request $request): View
    {
        return view('profile.edit', [
            'user' => $request->user(),
        ]);
    }

    /**
     * Update the user's profile information.
     */
    public function update(Request $request)
    {

        $profile = Profile::findOrFail($request->input("profile_id"));

        if (Auth::id() !== $profile->user_id) {
            abort(403, 'Unauthorized');
        }

        if ($profile) {

            $data = $request->all();
            unset($data['profile_id']);
            
            $profile->update($data);

            return response()->json($profile->description);
        }

        return response()->json([
            'success' => false,
            'message' => 'Profile not found.',
        ], 404);
    }

    /**
     * Delete the user's account.
     */
    public function destroy(Request $request): RedirectResponse
    {
        $request->validateWithBag('userDeletion', [
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        Auth::logout();

        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return Redirect::to('/');
    }

    public function storeProfile(Request $request, $step)
    {
        switch ($step) {
            case '1':
                break;
            case '2':
                $request->validate([
                    'industry' => 'exists:profile_industries,id',
                ]);

                session(['step2' => $request->only(['industry'])]);
                break;

            case '3':

                $request->validate([
                    'profile_type_id' => 'required|exists:profile_types,id',
                ]);
                session(['step3' => $request->only(['profile_type_id'])]);
                break;

            case '4':

                $request->validate([
                    'languages' => 'required|array',
                    'languages.*' => 'exists:industry_languages,id',
                ]);
                session(['step4' => $request->only(['languages'])]);
                break;

            case '5':
                $request->validate([
                    'title' => 'required|string|max:255',
                    'department' => 'required|exists:departments,id',
                ]);

                // Combine all session data
                $data = array_merge(
                    session('step2', []),
                    session('step3', []),
                    session('step4', []),
                    $request->all()
                );

                $profile = Profile::create([
                    'user_id' => auth()->user()->id,
                    'profile_type_id' => $data['profile_type_id'],
                    'department_id' => $data['department'],
                    'profile_industry_id' => $data['industry'],
                    'title' => $data['title'],
                    'status' => 'active',
                ]);

                // Attach languages
                //each profile has one industry only
                //$profile->industries()->attach($request->industries);
                $profile->languages()->attach($data['languages']);

                // Clear session data
                session()->forget(['step2', 'step3', 'step4', 'step5']);

                return redirect()->route('view-profile', ['id' => $profile->id])
                    ->with('success', 'Form submitted successfully!');
        }

        // Redirect to the next step       
        return redirect()->route('show-step', ['id' => $step + 1]);

    }
 
    public function signupSuccess()
    {
        return view("auth.signup_success");
    }

    public function showStep($step)
    {
        // Validate step number
        if (!in_array($step, ['1', '2', '3', '4', '5'])) {
            return redirect()->route('show-step', ['id' => 1]);
        }

        // Load step view
        switch ($step) {
            case '1':
                return view("auth.signup_success");
            case '2':
                $industries = ProfileIndustry::all();
                return view("profile.my_industry", compact("industries"));
            case '3':

                $profileIndustryId = session('step2')['industry'] ?? null;
                $profileTypes = ProfileType::where('profile_industry_id', $profileIndustryId)->get();
                return view("profile.my-profession-category", compact('profileTypes'));
            case '4':

                $profileIndustryId = session('step2')['industry'] ?? null;
                $languages = IndustryLanguage::where('profile_industry_id', $profileIndustryId)->get();
                return view("profile.my-industry-focus", compact('languages'));
            case '5':
                $departments = Department::where('profile_type_id', 1)->get();
                return view("profile.my-profession-details", compact('departments'));
            default:
                return view("auth.signup_success");
        }
    }

    public function viewProfile($profileId)
    {

        $profile = Profile::findOrFail($profileId);
        // Check if the user can view the profile
        if (Auth::id() !== $profile->user_id) {
            abort(403, 'Unauthorized');
        }

        session(['profileId' => $profileId]);
        return view('profile.my-profile', compact('profile'));
    }

    public function getAboutMe($profileId){        
        $aboutme = Profile::findOrFail($profileId)->description;
        return response()->json($aboutme, 200);
    }
}
