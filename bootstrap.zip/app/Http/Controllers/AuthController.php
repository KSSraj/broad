<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserOtp;
use App\Models\User;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use App\Mail\SendOtpMail;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Password;
use Symfony\Component\Mailer\Messenger\SendEmailMessage;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|min:8|confirmed',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Check if OTP is verified for this phone number
        $otpRecord = UserOtp::where('email', $request->email)->first();

        if (!$otpRecord || !$otpRecord->is_used) {
            return response()->json([
                'status' => 'error',
                'message' => 'You must verify the OTP before registering.',
            ], 403); // Forbidden
        }

        // Register user
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);

        $otpRecord->delete();
        // Update user's email verification

        $user->update([
            'email_verified_at' => Carbon::now(),
        ]);

        // // Assign a single role
        $user->assignRole('user');

        // Log the user in
        Auth::login($user);

        return response()->json(['message' => 'User registeredred successfully.']);
    }

    public function sendOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
           'email' => 'required|string|email|max:255|unique:users',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Generate OTP
        $otp = rand(100000, 999999);

        // Store OTP in the database
        UserOtp::updateOrCreate(
            ['email' => $request->email],
            [
                'otp' => $otp,
                'otp_expiry' => Carbon::now()->addMinutes(5), // OTP valid for 5 minutes
            ]
        );

        // Send OTP Email
        $this->sendOtpToUser($request->email, $otp);
        return response()->json(['message' => 'OTP sent successfully.']);

    }

    private function sendOtpToUser($email, $otp)
    {

        \Log::info("Sending OTP $otp to phone $email");
        // Implement SMS/Email sending logic here
        Mail::to($email)->send(new SendOtpMail($otp));
    }

    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
            'otp' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $otpRecord = UserOtp::where('email', $request->email)->first();

        if ($otpRecord->otp !== $request->otp) {
            return response()->json(['message' => 'Invalid OTP.'], 400);
        }

        if (Carbon::now()->greaterThan($otpRecord->otp_expiry)) {
            return response()->json(['message' => 'OTP has expired.'], 400);
        }

        // Mark OTP as used
        $otpRecord->update(['is_used' => true]);

        return response()->json([
            'message' => 'OTP verified successfully.',
        ]);

    }

    public function resendOtp(Request $request)
    {
        // Validate email input
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Find the user by email
        $otpRecord = UserOtp::where('email', $request->email)->first();

        if (!$otpRecord || Carbon::now()->greaterThan($otpRecord->otp_expiry)) {
            // Generate new OTP if none exists or if expired
            return $this->sendOtp($request);
        }

        $this->sendOtpToUser($otpRecord->email, $otpRecord->otp);
        return response()->json(['message' => 'OTP resent successfully.']);
    }

   
    public function login(Request $request)
    {
        // Validate the request
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors()
            ], 422);
        }

        // Find the user by email
        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return response()->json(['errors' => ['message' => 'Email or password is incorrect']], 422);
        }

        // Check if the email is verified (optional)
        if (!$user->email_verified_at) {
            return response()->json(['message' => 'Please verify your email first'], 403);
        }

        // Log the user in   
        if (Auth::attempt($request->only('email', 'password'))) {

            if ($user->profiles->count() > 0) {

                $defaultProfile = $user->profiles->first();
                return response()->json([
                    'success' => true,
                    'redirect' => url("/profile/" . $defaultProfile->id),
                ]);

            }
            return response()->json([
                'success' => true,
                'redirect' => url('profile/step/1'),
            ]);

        }

        return response()->json([
            'errors' => ['email' => ['The provided credentials are incorrect.']],
        ], 422);

    }

    public function forgotPassword(Request $request)
    {
        // Validate the request
        $request->validate([
            'email' => 'required|email|exists:users,email',
        ]);

        // Send the password reset link
        $status = Password::sendResetLink(
            $request->only('email')
        );

        if ($status === Password::RESET_LINK_SENT) {
            return response()->json(['message' => 'Password reset link sent to your email'], 200);
        }

        return response()->json(['message' => 'Unable to send reset link'], 500);
    }

    public function resetPassword(Request $request)
    {
        // Validate the request
        $request->validate([
            'token' => 'required',
            'email' => 'required|email|exists:users,email',
            'password' => 'required|min:8|confirmed',
        ]);

        // Reset the password
        $status = Password::reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function ($user, $password) {
                $user->forceFill([
                    'password' => Hash::make($password),
                ])->save();
            }
        );

        if ($status === Password::PASSWORD_RESET) {
            return response()->json(['message' => 'Password has been reset'], 200);
        }

        return response()->json(['message' => 'Invalid token or email'], 400);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Logged out successfully.']);
    }

}
