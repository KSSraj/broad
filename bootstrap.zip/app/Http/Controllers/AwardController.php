<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use App\Models\Profile;
use App\Models\ProfileHonorAward;
use Illuminate\Support\Facades\Validator;
class AwardController extends Controller
{
    //
  
    public function awards($profileId)
    {
        $experiences = ProfileHonorAward::where('profile_id', $profileId)
            ->orderBy('year', 'desc')          
            ->get();
        return response()->json($experiences);
    }
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [           
            "award_name" => "string|required",
            "description" => "string|required",          
            "year" => "integer|required",
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {

            $profile = Profile::findOrFail($request->profile_id);
            $experience = new ProfileHonorAward($request->all());
            $profile->honorsAwards()->save($experience);

            return response()->json( $experience);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }

    public function update(Request $request, ProfileHonorAward $award)
    {
        // dd($experience);
        $validator = Validator::make($request->all(), [
            "award_name" => "string|required",
            "description" => "string|required",          
            "year" => "integer|required",
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
            //$experience = ProfileExperience::findOrFail($request->id);            
            $award->update($request->all());
            return response()->json($award);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }
    public function destroy($expId)
    {
        $experience = ProfileHonorAward::findOrFail($expId);

        $experience->forceDelete();

        return response()->json([
            'success' => true,
            'message' => 'Award deleted successfully',
        ], 200);
    }

}
