<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProfilePolicy;
class ProfilePolicyController extends Controller
{
    //
    public function index($profileId)
    {
        return ProfilePolicy::where('profile_id', $profileId)->get();
    }

    public function store(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'profile_id' => 'required|exists:profiles,id',
            'name' => 'required|string|max:255',            
        ]);

        return ProfilePolicy::create($request->all());
    }

    public function destroy($id)
    {
        $policy = ProfilePolicy::findOrFail($id);
        $policy->delete();
        return response()->json(['message' => 'Skill deleted successfully'], 200);
    }
}
