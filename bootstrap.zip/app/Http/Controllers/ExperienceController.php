<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use App\Models\ProfileAttribute;
use App\Models\Profile;
use App\Models\ProfileExperience;
use Illuminate\Support\Facades\Validator;
class ExperienceController extends Controller
{
    //

    public function index($profileId)
    {
        $attributes = ProfileAttribute::where('profile_id', $profileId)->get();

        return response()->json([
            'message' => 'Profile attributes fetched successfully',
            'attributes' => $attributes,
        ], 200);
    }

    public function experiences($profileId)
    {
        $experiences = ProfileExperience::where('profile_id', $profileId)
            ->orderBy('year', 'desc')
            ->orderBy('month', 'desc')
            ->get();
        return response()->json($experiences);
    }
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            "experience_type" => "string|required",
            "experience_title" => "string|required",
            "details" => "string|required",
            "link" => "string|required",
            "month" => "string|required",
            "year" => "integer|required",
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {

            $profile = Profile::findOrFail($request->profile_id);
            $experience = new ProfileExperience($request->all());
            $profile->experiences()->save($experience);

            return response()->json([
                'message' => 'Experience added successfully!',
                'experience' => $experience,
            ]);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }

    public function update(Request $request, ProfileExperience $experience)
    {
        // dd($experience);
        $validator = Validator::make($request->all(), [
            "experience_type" => "string|required",
            "experience_title" => "string|required",
            "details" => "string|required",
            "link" => "string|required",
            "month" => "string|required",
            "year" => "integer|required",
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
            //$experience = ProfileExperience::findOrFail($request->id);            
            $experience->update($request->all());
            return response()->json([
                'message' => 'Experience updated successfully!',
                'experience' => $experience,
            ]);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }
    public function destroy($expId)
    {
        $experience = ProfileExperience::findOrFail($expId);

        $experience->forceDelete();

        return response()->json([
            'success' => true,
            'message' => 'Experience deleted successfully',
        ], 200);
    }

}
