<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProfileDocument;
use App\Models\Profile;
class ProfileDocumentController extends Controller
{
    //
    public function index($profileId)
    {
        return ProfileDocument::where('profile_id', $profileId)->get();
    }

    public function store(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'profile_id' => 'required|exists:profiles,id',
        ]);

        $profileId = $request->input('profile_id');
        $documents = [
            ['profile_id' => $profileId, 'name' => 'driving_licence', 'is_available' => $request->input('driving_licence') ? 1 : 0],
            ['profile_id' => $profileId, 'name' => 'passport', 'is_available' => $request->input('passport') ? 1 : 0],
            ['profile_id' => $profileId, 'name' => 'resume', 'is_available' => $request->input('resume') ? 1 : 0],
        ];

        //  ProfileDocument::insert($documents); 
        ProfileDocument::upsert($documents, ['profile_id', 'name'], ['is_available']);
        return Profile::find($profileId)->documents;
    }

    public function destroy($id)
    {
        $policy = ProfileDocument::findOrFail($id);
        $policy->delete();
        return response()->json(['message' => 'Skill deleted successfully'], 200);
    }
}
