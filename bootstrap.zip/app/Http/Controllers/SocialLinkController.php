<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SocialLink;
use App\Models\Profile;
class SocialLinkController extends Controller
{
    //
    public function index()
    {
        // Fetch all social links (or based on a user)
        $socialLinks = SocialLink::with('profile')->get();
        return response()->json($socialLinks);
    }

    public function show($id)
    {
        $socialLink = Profile::findOrFail($id)->socialLinks;
        return response()->json($socialLink);
    }
    public function store(Request $request)
    {
        $validated = $request->validate([
            'profile_id' => 'required|exists:profiles,id',
            'platform' => 'required|string|max:255',
            'url' => 'required|url',
        ]);

        $socialLink = SocialLink::create($validated);

        return response()->json($socialLink, 201);
    }
    public function update(Request $request, $id)
    {
        $socialLink = SocialLink::findOrFail($id);

        $validated = $request->validate([
            'platform' => 'sometimes|required|string|max:255',
            'url' => 'sometimes|required|url',
        ]);

        $socialLink->update($validated);

        return response()->json($socialLink);
    }
    public function destroy($id)
    {
        $socialLink = SocialLink::findOrFail($id);
        $socialLink->delete();

        return response()->json(null, 204);
    }

}
