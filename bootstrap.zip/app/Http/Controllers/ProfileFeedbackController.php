<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use App\Models\Profile;
use App\Models\ProfileFeedback;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
class ProfileFeedbackController extends Controller
{
    //
  
    public function feedbacks($profileId)
    {
        $feedbacks = ProfileFeedback::where('profile_id', $profileId)
            ->orderBy('created_at', 'desc')            
            ->get();
        return response()->json($feedbacks);
    }
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [            
            "feedback" => "string|required",                       
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {

            $profile = Profile::findOrFail($request->profile_id);
            $feedback = new ProfileFeedback($request->all());
            $feedback->user_id = Auth::user()->id;
            $profile->feedbacks()->save($feedback);

            return response()->json($feedback);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }

    public function update(Request $request, ProfileFeedback $feedback)
    {
        // dd($experience);
        $validator = Validator::make($request->all(), [            
            "description" => "string|required",         
            "year" => "integer|required",
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
                   
            $feedback->update($request->all());
            return response()->json($feedback);

        } catch (Exception $e) {

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }

    }
    public function destroy($eduId)
    {
        $feedback = ProfileFeedback::findOrFail($eduId);

        $feedback->forceDelete();

        return response()->json([
            'success' => true,
            'message' => 'Education deleted successfully',
        ], 200);
    }

}
