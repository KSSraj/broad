<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProfileSkill;
class ProfileSkillController extends Controller
{
    //
    public function index($profileId)
    {
        return ProfileSkill::where('profile_id', $profileId)->get();
    }

    public function store(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'profile_id' => 'required|exists:profiles,id',
            'name' => 'required|string|max:255',
            'level' => 'required|string|max:255',
        ]);

        return ProfileSkill::create($request->all());
    }

    public function destroy($id)
    {
        $skill = ProfileSkill::findOrFail($id);
        $skill->delete();
        return response()->json(['message' => 'Skill deleted successfully'], 200);
    }
}
