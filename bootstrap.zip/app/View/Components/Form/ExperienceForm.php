<?php
namespace App\View\Components\Form;

use Illuminate\View\Component;

class ExperienceForm extends Component
{
    public $action;
    public $method;
    public $experience;
    public $buttonText;

    public function __construct($action=null, $method = 'POST', $experience = null, $buttonText = 'Submit')
    {
        $this->action = $action;
        $this->method = strtoupper($method);
        $this->experience = $experience;
        $this->buttonText = $buttonText;
    }

    public function render()
    {
        return view('components.form.experience-form');
    }
}
