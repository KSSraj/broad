<?php

namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class NavbarWithoutMenuComponent extends Component
{
   
    public $title; 
    public $subtitle; 

    public function __construct( $title = '',$subtitle='')
    {     
        $this->title = $title; 
        $this->subtitle = $subtitle; 
    }
 
    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        $this->title = auth()->user()->name ?? "";
        $this->subtitle = auth()->user()->profiles()->first()->name??"";
        return view('components.navbar-without-menu-component');
    }
}
