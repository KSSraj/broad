<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Profile extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'profile_type_id',
        'department_id',
        'profile_industry_id',
        'title',
        'description',
        'slug',
        'profile_photo',
        'status'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function attributes()
    {
        return $this->hasMany(ProfileAttribute::class);
    }

    public function documents()
    {
        return $this->hasMany(ProfileDocument::class);
    }

    public function media()
    {
        return $this->hasMany(ProfileMedia::class);
    }

    public function experiences()
    {
        return $this->hasMany(ProfileExperience::class);
    }

    public function honorsAwards()
    {
        return $this->hasMany(ProfileHonorAward::class);
    }

    public function highlights()
    {
        return $this->hasMany(ProfileHighlight::class);
    }

    public function contacts()
    {
        return $this->hasMany(ProfileContact::class);
    }

    public function profileType()
    {
        return $this->belongsTo(ProfileType::class);
    }

    public function industry()
    {
        return $this->belongsTo(ProfileIndustry::class, 'profile_industry_id');
    }

    //each profile has only one industry
    // public function industries()
    // {
    //     return $this->belongsToMany(ProfileIndustry::class, 'profile_industry_pivot', 'profile_id', 'industry_id');
    // }
    public function languages()
    {
        return $this->belongsToMany(IndustryLanguage::class, 'profile_language_pivot', 'profile_id', 'language_id');
    }
    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function skills()
    {
        return $this->hasMany(ProfileSkill::class);
    }
    public function policies()
    {
        return $this->hasMany(ProfilePolicy::class);
    }

    public function socialLinks()
    {
        return $this->hasMany(SocialLink::class);
    }
    public function educations()
    {
        return $this->hasMany(ProfileEducation::class);
    }

    public function feedbacks()
    {
        return $this->hasMany(ProfileFeedback::class);
    }
}
