<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class ProfileEducation extends Model
{
    //
    use HasFactory;

    protected $fillable = ['year', 'description','profile_id'];
}
