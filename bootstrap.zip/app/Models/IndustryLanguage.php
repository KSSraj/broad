<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IndustryLanguage extends Model
{
    use HasFactory;

    protected $fillable = ['name','profile_industry_id']; // e.g., 'Hindi', 'Marathi'

    public function profiles()
    {
        return $this->belongsToMany(Profile::class, 'profile_language_pivot', 'language_id', 'profile_id');
    }

    public function industry()
    {
        return $this->belongsTo(ProfileIndustry::class);
    }
}
