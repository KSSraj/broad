<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProfileType extends Model
{
    use HasFactory;

    protected $fillable = ['name','profile_industry_id']; // e.g., 'Actor', 'Voice Over Artist'

    public function profiles()
    {
        return $this->hasMany(Profile::class);
    }

    public function industry()
    {
        return $this->belongsTo(ProfileIndustry::class, 'profile_industry_id');
    }

    public function departments()
    {
        return $this->hasMany(Department::class);
    }
}
