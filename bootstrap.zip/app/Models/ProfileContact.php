<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ProfileContact extends Model
{
    use HasFactory;

    protected $fillable = [
        'profile_id', 'contact_type', 'name', 'mobile', 'email', 'address',
    ];

    public function profile()
    {
        return $this->belongsTo(Profile::class);
    }
}
