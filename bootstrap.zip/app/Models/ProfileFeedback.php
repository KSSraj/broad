<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ProfileFeedback extends Model
{
    use HasFactory;

    protected $table = "profile_feedbacks";
    protected $fillable = [
        'profile_id', 'feedback','user_id',
    ];

    public function profile()
    {
        return $this->belongsTo(Profile::class);
    }
}
