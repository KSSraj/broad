<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ProfileAttribute extends Model
{
    use HasFactory;

    protected $fillable = [
        'profile_id', 'attribute_key', 'attribute_value',
    ];

    public function profile()
    {
        return $this->belongsTo(Profile::class);
    }
}

