<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProfileIndustry extends Model
{
    use HasFactory;

    protected $fillable = ['name']; // e.g., 'Film', 'TV', 'OTT'

    public function profiles()
    {
        return $this->belongsToMany(Profile::class, 'profile_industry_pivot', 'industry_id', 'profile_id');
    }

    public function profileTypes()
    {
        return $this->hasMany(ProfileType::class);
    }

    public function languages()
    {
        return $this->hasMany(IndustryLanguage::class);
    }
}
