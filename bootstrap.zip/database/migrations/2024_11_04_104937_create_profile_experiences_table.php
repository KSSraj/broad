<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('profile_experiences', function (Blueprint $table) {
            $table->id();
            $table->foreignId('profile_id')->constrained()->onDelete('cascade'); // Link to profiles table
            $table->string('experience_type'); // Type of experience (e.g., theater, movie)
            $table->string('experience_title'); // Type of experience (e.g., theater, movie)
            $table->text('details')->nullable(); // Experience details (could be JSON for complex info)
            $table->text('link')->nullable(); // Experience details (could be JSON for complex info)
            $table->string('month')->nullable(); // Experience details (could be JSON for complex info)
            $table->year('year')->nullable(); // Year of the experience
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('profile_experiences');
    }
};
