<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('profile_contacts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('profile_id')->constrained()->onDelete('cascade'); // Link to profiles table
            $table->enum('contact_type', ['basic', 'representative']); // Contact type
            $table->string('name'); // Name of the person
            $table->string('mobile')->nullable(); // Mobile number
            $table->string('email')->nullable(); // Email address
            $table->string('address')->nullable(); // Physical address
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('profile_contacts');
    }
};
