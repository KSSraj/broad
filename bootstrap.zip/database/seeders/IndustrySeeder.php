<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\ProfileIndustry;
use App\Models\IndustryLanguage;
use App\Models\ProfileType;

class IndustrySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Seed Profile Industries
        $industries = ['Film', 'TV', 'OTT', 'Theater'];

        foreach ($industries as $industry) {
            ProfileIndustry::firstOrCreate(['name' => $industry]);
        }

        $filmIndustry = ProfileIndustry::firstOrCreate(['name' => 'Film']);

        // Seed Languages for Industry
        $filmIndustry->languages()->createMany([
            ['name' => 'Hindi'],
            ['name' => 'English'],
            ['name' => 'Marathi'],
        ]);
     
        // Seed Profile Types
        $actorType = $filmIndustry->profileTypes()->create(['name' => 'Actor']);
        
        // Seed Departments for Profile Type
        $actorType->departments()->createMany([
            ['name' => 'Lead Actor'],
            ['name' => 'Supporting Actor'],
        ]);
        
    }
}
