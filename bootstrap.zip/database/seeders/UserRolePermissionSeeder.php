<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class UserRolePermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */

    protected $models = [
        'Department',
        'IndustryLanguage',
        'Profile',
        'ProfileAttribute',
        'ProfileContact',
        'ProfileHonorAward',
        'ProfileMedia',
        'ProfileDocument',
        'ProfileExperience',
        'ProfileHighlight',
        'ProfileType',
        'ProfileIndustry',
        'User',
    ];

    public function run(): void
    {

        foreach ($this->models as $model) {
            // Generate basic permissions for the model
            $this->generatePermissionsForModel($model);
        }

        // Create Roles        
        // reuqet->pageOwner = page all
        // ->user list -> select user as page manager(multiple) 
        // pageManager = limited (system defined)

        $superadminRole = Role::create(['name' => 'superadmin']);
        //$adminRole=Role::create(['name' => 'admin']);
        $userRole = Role::create(['name' => 'user']);

        // Assign permissions to roles
        $superadminRole->givePermissionTo(Permission::all()); // Give all permissions to admin        
        $userRole->givePermissionTo(['store profile','view profile','index profile','edit profile','update profile','delete profile']);

    }

    public function generatePermissionsForModel($model)
    {
        $actions = ['create', 'store', 'view', 'view_any', 'edit', 'edit_any', 'index', 'index_any', 'update', 'update_any', 'delete', 'delete_any'];

        foreach ($actions as $action) {
            // Define permission name, e.g., "create department", "view department"
            $permissionName = strtolower("{$action} {$model}");

            // Create the permission if it doesn't already exist
            if (!Permission::where('name', $permissionName)->exists()) {
                Permission::create(['name' => $permissionName]);
            }
        }
    }
}