<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div>About me</div>
            <a href="javascript:;" v-if="aboutme"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openEditModal(aboutme)">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->
        <about-me :aboutme="aboutme || ''" />
        <div v-if="!aboutme">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openEditModal(aboutme)">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="aboutmeModal" :title="aboutme ? 'Edit Document' : 'Add Document'">
        <about-me-form :initial-profile-id="profileId" @formSubmitted="updateAboutme" :initial-data="aboutme" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>

import ModalComponent from '../experiences/ModalComponent.vue';
import AboutMe from './AboutMe.vue';
import AboutMeForm from './AboutMeForm.vue';

export default {
    components: {
        AboutMe,
        ModalComponent,
        AboutMeForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            aboutme: null, // List of experiences
            selectedAboutme: null, // Experience selected for editing                    
        };
    },
    methods: {
        // Fetch experiences from the server
        async fetchAboutme() {
            try {
                const response = await axios.get(`/profile/aboutme/${this.profileId}`);
                this.aboutme = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedAboutme = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList

        openEditModal(aboutmetext) {           
            this.aboutme = aboutmetext; // Set experience for editing
            this.$refs.modal.showModal();
        },

        // Update experiences after form submission
        updateAboutme(updatedDocument) {
            this.aboutme = updatedDocument;
            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchAboutme();
    },
};
</script>
<style scoped></style>