<template>
    <div>
        {{ aboutme }}
    </div>
</template>
<script>
export default {
    props: {
        aboutme: {
            type: [String, null],
            required: true,
            default: null,
        },
    },
};
</script>
<style scoped></style>
