<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div> Credits / Experience</div>
            <a href="javascript:;" v-if="experiences.length > 0"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none" @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>

    </div>
    <div class="card-body">
        <!-- Filter Chips -->
        <div class="d-flex gap-2 mb-2">
            <span v-for="type in experienceTypeCounts" :key="type.name" class="chip badge rounded-pill border border-dark"
                :class="{ active: selectedType === type.name }" @click="filterByType(type.name)">
                {{ type.name }} ({{ type.count }})
            </span>
            <!-- Clear filter chip -->
            <span class="chip badge rounded-pill border border-dark" :class="{ active: !selectedType }"
                @click="filterByType(null)">
                All ({{ experiences.length }})
            </span>
        </div>
        <experience-list :experiences="filteredExperiences" @editExperience="openEditModal"
            @deleteExperience="deleteExperience" />
        <div v-if="experiences.length <= 0">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="experienceModal"
        :title="selectedExperience ? 'Edit Experience' : 'Add Experience'">
        <experience-form :initial-profile-id="profileId" :initial-data="selectedExperience"
            @formSubmitted="updateExperienceList" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>
import ExperienceList from './ExperienceList.vue';
import ModalComponent from './ModalComponent.vue';
import ExperienceForm from './ExperienceForm.vue';

export default {
    components: {
        ExperienceList,
        ModalComponent,
        ExperienceForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            experiences: [], // List of experiences
            selectedExperience: null, // Experience selected for editing          
            experienceTypes: ['Theatre', 'Movie', 'TV', 'Video'],
            selectedType: null,
        };
    },
    computed: {
        filteredExperiences() {
            if (!this.selectedType) {
                return this.experiences; // Return all experiences if no filter is selected
            }
            return this.experiences.filter(exp => exp.type === this.selectedType);
        },
        // Count experiences for each type
        experienceTypeCounts() {
            return this.experienceTypes.map((type) => {
                const count = this.experiences.filter((exp) => exp.type === type).length;
                return { name: type, count };
            });
        },
    },
    methods: {
        filterByType(type) {
            this.selectedType = type;
        },
        // Fetch experiences from the server
        async fetchExperiences() {
            try {
                const response = await axios.get(`/profile/experiences/${this.profileId}`);
                this.experiences = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedExperience = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList

        openEditModal(experience) {
            this.selectedExperience = { ...experience }; // Set experience for editing
            this.$refs.modal.showModal();
        },
        async deleteExperience(id) {
            try {
                await axios.delete(`/profile/experience/${id}`);
                this.experiences = this.experiences.filter((exp) => exp.id !== id); // Remove from list
            } catch (error) {
                console.error('Error deleting experience:', error);
            }
        },
        // Update experiences after form submission
        updateExperienceList(updatedExperience) {
            const index = this.experiences.findIndex((exp) => exp.id === updatedExperience.id);
            if (index !== -1) {
                // Update existing experience
                this.experiences.splice(index, 1, updatedExperience);
            } else {
                // Add new experience
                this.experiences.unshift(updatedExperience);
            }
            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchExperiences();
    },
};
</script>
<style scoped>
.chip {
    font-size: 14px;
    font-weight: normal;
    color: #000;
    cursor: pointer;
}

.chip.active {
    background-color: #000;
    color: white;
}
</style>