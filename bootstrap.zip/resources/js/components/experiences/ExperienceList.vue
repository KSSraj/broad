<template>
    <div class="row row-cols-1 row-cols-md-2 g-3">
        <div class="col" v-for="experience in experiences" :key="experience.id">
            <div class="card h-100">                
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title px-1 py-1">
                            {{ experience.experience_title }}
                            <span class="fw-normal">({{ experience.month }}-{{ experience.year }})</span>
                        </h5>
                        <a href="javascript:;"
                            class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                            @click="$emit('editExperience', experience)">
                            <img class="add-icon" src="/images/edit-circle.svg" height="18" width="18" alt="Edit" />
                        </a>
                        <a href="javascript:;"
                            class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                            @click="$emit('deleteExperience', experience.id)">
                            <img class="add-icon" src="/images/remove-circle.svg" height="22" width="22" alt="Edit" />
                        </a>
                       
                    </div>
                    <p class="card-text">{{ experience.details }}</p>
                    <a :href="experience.link" class="">{{ experience.link }}</a>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        experiences: {
            type: Array,
            required: true,
        },
    },
};
</script>

<style scoped>
.add-icon {
    cursor: pointer;
}
</style>