<template>
    <form @submit.prevent="submitForm">
        <div class="form-group">
            <label for="experience_type" class="form-label">Experience Type</label>
            <input class="form-control" type="text" name="experience_type" v-model="form.experience_type"
                id="experience_type" required>
            <input type="number" class="d-nones" v-model="form.profile_id" id="profile_id" name="profile_id" />
        </div>
        <div class="form-group">
            <label for="experience_title" class="form-label">Experience Title</label>
            <input class="form-control" type="text" name="experience_title" v-model="form.experience_title"
                id="experience_title" required>
        </div>
        <div class="form-group">
            <label for="details" class="form-label">Details</label>
            <textarea class="form-control" name="details" v-model="form.details" id="details"></textarea>
        </div>
        <div class="form-group">
            <label for="link" class="form-label">Link</label>
            <input class="form-control" name="link" v-model="form.link" id="link" required>
        </div>
        <div class="form-group">
            <label for="month" class="form-label">Month</label>
            <input class="form-control" type="text" name="month" v-model="form.month" id="month" required>
        </div>
        <div class="form-group">
            <label for="year" class="form-label">Year</label>
            <input class="form-control" type="number" name="year" v-model="form.year" id="year" required>
            <input type="hidden" name="experience_id" v-model="form.experience_id" id="experience_id">
        </div>
        <button type="submit" class="btn btn-success my-2"> {{ form.id ? 'Update' : 'Save' }}</button>
        <!-- <x-primary-button>{{ $buttonText }}</x-primary-button> -->
    </form>
    <div v-if="message" :class="{ 'success': success, 'error': !success }">
        {{ message }}
    </div>
</template>
<script>
import axios from 'axios';
export default {
    emits: ['formSubmitted'],
    props: {
        initialData: {
            type: Object,
            default: () => ({}),
        },
        initialProfileId: {
            type: Number,
            required: true,
            default: 0,
        },
    },
    data() {        
        return {            
            form: { 
                profile_id: this.initialProfileId, 
                ...this.initialData 
            },
            message: '',
            success: false,
        };
    },
    watch: {
        initialData: {
            deep: true,
            immediate: true,
            handler(newData) {
                // Update the form and retain profile_id
                this.form = { ...newData, profile_id: this.form.profile_id || this.initialProfileId };
            },
        },
    },
    methods: {
        async submitForm() {
            try {
                const url = this.form.id
                    ? `/profile/experience/${this.form.id}`
                    : '/profile/experience';
                const method = this.form.id ? 'put' : 'post';

                const response = await axios[method](url, this.form);
                this.$emit('formSubmitted', response.data.experience);

                this.message = response.data.message;
                this.success = true;
                this.form = {
                    ...this.form,
                    experience_type: '',
                    experience_title: '',
                    details: '',
                    month: '',
                    year: '',
                    link: '',
                };

                setTimeout(() => {
                    this.successMessage = '';
                }, 3000);

            } catch (error) {
                this.message = error.response?.data?.message || 'An error occurred.';
                this.success = false;
            }
        },
    },
};
</script>

<style>
.success {
    color: green;
}

.error {
    color: red;
}
</style>
