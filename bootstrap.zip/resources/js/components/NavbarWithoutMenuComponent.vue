<template>
    <div class="mb-2 curveNav">
        <nav class="navbar navbar-expand-lg  navbar-dark ">
            <div class="container-fluid">
                <!-- Logo -->
                <a class="navbar-brand" href="#">
                    <img :src="logoHeaderSrc" alt="Logo" height="48">
                </a>
                <!-- Toggle button -->
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                <!-- First menu section -->
                    <ul class="d-flex navbar-nav gap-1  justify-content-xxl-start search-box-div">
                        
                        <!-- industry insights menu -->

                    </ul>
                    <!-- Right aligned nav items -->
                    <!--  Main menu -->
                    <ul class="main-menu navbar-nav ms-auto ">


                        <li class="v-line">
                            <img :src="white_pipe_icon" alt="white pipe icon" >
                        </li>
                        <!-- Profile menu -->
                        <li class="nav-item dropdown gap-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12 10C14.2091 10 16 8.20914 16 6C16 3.79086 14.2091 2 12 2C9.79086 2 8 3.79086 8 6C8 8.20914 9.79086 10 12 10Z"
                                    stroke="white" stroke-opacity="0.9" stroke-width="1.5"/>
                                <path
                                    d="M19.998 18C20 17.836 20 17.669 20 17.5C20 15.015 16.418 13 12 13C7.582 13 4 15.015 4 17.5C4 19.985 4 22 12 22C14.231 22 15.84 21.843 17 21.563"
                                    stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round"/>
                            </svg>
                            <div class="d-flex flex-column">
                                <span class="userName pointer" :title="profileName"> {{ profileName }}</span>
                                <em><span class="span-profile-as">Actor / Performer </span></em>
                            </div>
                            <a class="nav-link px-0" href="#" id="navbarLang" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6 9L12 15L18 9" stroke="white" stroke-opacity="0.9" stroke-width="2"
                                          stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>

                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarUser">
                                <li><a class="dropdown-item" href="#">Profile</a></li>
                                <li><a class="dropdown-item" href="#">Sign Out</a></li>
                            </ul>

                        </li>

                        <li class="v-line">
                            <img :src="white_pipe_icon" alt="white pipe icon" >
                        </li>

                        <!-- Last menu -->
                        <li class="nav-item ">
                            <a class="nav-link " href="#" id="navbarUser" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                               <img :src="nine_dot_icon" width="32" height="32"  alt="nine dots"/>
                            </a>

                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="header-curve-div"></div>
    </div>
</template>
<script setup>
defineProps(['profileName']);
let a = null;
const profileName = "Shahrukh Khan";
</script>

<script>
export default {
    data() {
        return {
            logoHeaderSrc: '/images/logo_header.svg',
            nine_dot_icon: '/images/nine-dot-icon.svg',
            bulbIcon: '/images/bulb-icon.svg',
            white_pipe_icon: '/images/white-pipe-icon.svg',

        }
    },
    mounted() {

        console.log('Navbar mounted.')
    }
}
</script>
