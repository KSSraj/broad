<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Example Component</div>

                    <div class="card-body" >
                        I'm an example component.
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
 import axios from "axios";

    export default {

        mounted() {
            axios.get("http://127.0.0.1:8000/api/test").then((response) => {
                console.log(response.data);

            })
            console.log('Component mounted.')
        }
    }
</script>
