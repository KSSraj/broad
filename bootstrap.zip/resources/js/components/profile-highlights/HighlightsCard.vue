<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div> Highlights</div>
            <a href="javascript:;" v-if="highlights.length > 0"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none" @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->      
        <highlights-list :highlights="highlights" @editHighlight="openEditModal"
            @deleteHighlight="deleteHighlight" />
        <div v-if="highlights.length <= 0">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="highlightsModal"
        :title="selectedHighlight ? 'Edit Education' : 'Add Education'">
        <highlights-form :initial-profile-id="profileId" :initial-data="selectedHighlight"
            @formSubmitted="updateHighlightList" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>
import HighlightsList from './HighlightsList.vue';
import ModalComponent from '../experiences/ModalComponent.vue';
import HighlightsForm from './HighlightsForm.vue';

export default {
    components: {
        HighlightsList,
        ModalComponent,
        HighlightsForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            highlights: [], // List of experiences
            selectedHighlight: null, // Experience selected for editing                              
        };
    },   
    methods: {      
        // Fetch experiences from the server
        async fetchHighlights() {
            try {
                const response = await axios.get(`/highlight/${this.profileId}`);
                this.highlights = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedHighlight = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList

        openEditModal(highlight) {
            this.selectedHighlight = { ...highlight }; // Set experience for editing
            this.$refs.modal.showModal();
        },
        async deleteHighlight(id) {
            try {
                await axios.delete(`/highlight/${id}`);
                this.highlights = this.highlights.filter((exp) => exp.id !== id); // Remove from list
            } catch (error) {
                console.error('Error deleting education:', error);
            }
        },
        // Update experiences after form submission
        updateHighlightList(updatedHighlight) {
            const index = this.highlights.findIndex((exp) => exp.id === updatedHighlight.id);
            if (index !== -1) {
                // Update existing experience
                this.highlights.splice(index, 1, updatedHighlight);
            } else {
                // Add new experience
                this.highlights.unshift(updatedHighlight);
            }
            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchHighlights();
    },
};
</script>
<style scoped>

</style>