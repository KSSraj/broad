<template>
    <div class="row">
        <div class="col-md-6" v-for="highlight in highlights" :key="highlight.id">
            <ul>
                <li>
                    <div class="d-flex gap-3">
                        <span class="fw-bold">{{ highlight.year }}</span>
                        <div>{{ highlight.title }}</div>
                        <div>{{ highlight.description }}</div>
                        <div class="d-flex gap-2 align-items-center">
                            <a href="javascript:;"
                                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                                @click="$emit('editHighlight', highlight)">
                                <img class="add-icon" src="/images/edit-circle.svg" height="18" width="18" alt="Edit" />
                            </a>
                            <a href="javascript:;"
                                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                                @click="$emit('deleteHighlight', highlight.id)">
                                <img class="add-icon" src="/images/remove-circle.svg" height="22" width="22"
                                    alt="Edit" />
                            </a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        highlights: {
            type: Array,
            required: true,
        },
    },
    emits: ['editHighlight', 'deleteHighlight'],
};
</script>

<style scoped>
.add-icon {
    cursor: pointer;
}
</style>