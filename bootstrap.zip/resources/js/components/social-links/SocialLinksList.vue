<template>
    <ul class="list-group w-100">
        <li v-for="link in socialLinks" :key="link.id" class="list-group-item d-flex align-items-center">
            <!-- SVG Icon -->
            {{ link.platform }}
            <a href="javascript:;"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none text-danger"
                @click="$emit('deleteSocialLink', link.id)">
                x
            </a>
        </li>
    </ul>
</template>
<script>
export default {
    props: {
        socialLinks: {
            type: Array,
            required: true,
        },
    },
};
</script>
<style scoped></style>
