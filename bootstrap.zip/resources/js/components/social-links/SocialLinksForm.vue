<template>
    <form @submit.prevent="addSocialLink">
        <div class="mb-3">
            <label for="policy" class="form-label">Enter Social Platform</label>
            <input type="text" v-model="form.platform" name="platform" placeholder="Enter platform" required
                class="form-control" />
            <label for="policy" class="form-label">Enter Social URL</label>
            <input type="text" v-model="form.url" name="url" placeholder="Enter url" required class="form-control" />
            <input type="number" class="d-nones" v-model="form.profile_id" id="profile_id" name="profile_id" />
        </div>
        <button type="submit" class="btn btn-success">Add Social Link</button>
    </form>
    <div v-if="message" :class="{ 'success': success, 'error': !success }">
        {{ message }}
    </div>
</template>

<script>
export default {
    emits: ['formSubmitted'],
    props: {
        initialData: {
            type: Object,
            default: () => ({}),
        },
        initialProfileId: {
            type: Number,
            required: true,
            default: 0,
        },
    },
    data() {
        return {
            form: {
                profile_id: this.initialProfileId,
                ...this.initialData
            },
            message: '',
            success: false,
        };
    },
    watch: {
        initialData: {
            deep: true,
            immediate: true,
            handler(newData) {
                // Update the form and retain profile_id
                this.form = { ...newData, profile_id: this.form.profile_id || this.initialProfileId };
            },
        },
    },
    methods: {
        async addSocialLink() {
            try {

                const response = await axios.post('/social-links', this.form);
                this.$emit('formSubmitted', response.data);
                this.message = response.data.message;

                this.success = true;
                this.form = {
                    ...this.form,
                    name: '',
                };

            } catch (error) {
                console.error('Error adding skill:', error);
            }
        },
    },
};
</script>