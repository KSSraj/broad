<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div>Social Media / Links</div>
            <a href="javascript:;" v-if="socialLinks.length > 0"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none" @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->
        <social-links-list :socialLinks="socialLinks"  @deleteSocialLink="deleteSocialLink"/>
        <div v-if="socialLinks.length <= 0">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="socialLinkModal" :title="selectedSocialLink ? 'Edit Link' : 'Add Link'">
        <social-links-form :initial-profile-id="profileId" @formSubmitted="updateSocialLinkList" :initial-data="selectedSocialLink" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>
import SocialLinksList from './SocialLinksList.vue';
import ModalComponent from '../experiences/ModalComponent.vue';
import SocialLinksForm from './SocialLinksForm.vue';

export default {
    components: {
        SocialLinksList,
        ModalComponent,
        SocialLinksForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            socialLinks: [], // List of experiences
            selectedSocialLink: null, // Experience selected for editing                    
        };
    },
    methods: {
        // Fetch experiences from the server
        async fetchSocialLinks() {
            try {
                const response = await axios.get(`/social-links/${this.profileId}`);
                this.socialLinks = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedSocialLink = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList
       
        async deleteSocialLink(id) {
            try {
                await axios.delete(`/social-links/${id}`);
                this.socialLinks = this.socialLinks.filter((exp) => exp.id !== id); // Remove from list
            } catch (error) {
                console.error('Error deleting experience:', error);
            }
        },

        // Update experiences after form submission
        updateSocialLinkList(updatedSocialLink) {
            const index = this.socialLinks.findIndex((link) => link.id === updatedSocialLink.id);
            if (index !== -1) {
                // Update existing experience
                this.socialLinks.splice(index, 1, updatedSocialLink);
            } else {
                // Add new experience
                this.socialLinks.unshift(updatedSocialLink);
            }
            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchSocialLinks();
    },
};
</script>
<style scoped></style>