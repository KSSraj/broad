<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div>Skills</div>
            <a href="javascript:;" v-if="skills.length > 0"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none" @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->
        <skill-list :skills="skills"  @deleteSkill="deleteSkill"/>
        <div v-if="skills.length <= 0">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="skillModal" :title="selectedSkill ? 'Edit Skill' : 'Add Skill'">
        <skill-form :initial-profile-id="profileId" @formSubmitted="updateSkillList" :initial-data="selectedSkill" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>
import SkillList from './SkillList.vue';
import ModalComponent from '../experiences/ModalComponent.vue';
import SkillForm from './SkillForm.vue';

export default {
    components: {
        SkillList,
        ModalComponent,
        SkillForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            skills: [], // List of experiences
            selectedSkill: null, // Experience selected for editing                    
        };
    },
    methods: {
        // Fetch experiences from the server
        async fetchSkills() {
            try {
                const response = await axios.get(`/profiles/${this.profileId}/skills`);
                this.skills = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedSkill = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList

        openEditModal(skill) {
            this.selectedSkill = { ...skill }; // Set experience for editing
            this.$refs.modal.showModal();
        },
        async deleteSkill(id) {
            try {
                await axios.delete(`/skills/${id}`);
                this.skills = this.skills.filter((exp) => exp.id !== id); // Remove from list
            } catch (error) {
                console.error('Error deleting experience:', error);
            }
        },

        // Update experiences after form submission
        updateSkillList(updatedSkill) {
            const index = this.skills.findIndex((skill) => skill.id === updatedSkill.id);
            if (index !== -1) {
                // Update existing experience
                this.skills.splice(index, 1, updatedSkill);
            } else {
                // Add new experience
                this.skills.unshift(updatedSkill);
            }
            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchSkills();
    },
};
</script>
<style scoped>
</style>