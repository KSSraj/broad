<template>
    <form @submit.prevent="addSkill">
        <div class="mb-3">
            <label for="skill" class="form-label">Enter skill</label>
            <input type="text" v-model="form.name" name="name" placeholder="Enter skill" required
                class="form-control" />
            <input type="number" class="d-nones" v-model="form.profile_id" id="profile_id" name="profile_id" />
        </div>
        <div class="mb-3">
            <label for="formGroupExampleInput2" class="form-label">Skill level</label>
            <input type="text" v-model="form.level" name="level" placeholder="Enter level" required
                class="form-control" />
        </div>
        <button type="submit" class="btn btn-success">Add Skill</button>
    </form>
    <div v-if="message" :class="{ 'success': success, 'error': !success }">
        {{ message }}
    </div>
</template>

<script>
export default {
    emits: ['formSubmitted'],
    props: {
        initialData: {
            type: Object,
            default: () => ({}),
        },
        initialProfileId: {
            type: Number,
            required: true,
            default: 0,
        },
    },
    data() {
        return {
            form: {
                profile_id: this.initialProfileId,
                ...this.initialData
            },
            message: '',
            success: false,
        };
    },
    watch: {
        initialData: {
            deep: true,
            immediate: true,
            handler(newData) {
                // Update the form and retain profile_id
                this.form = { ...newData, profile_id: this.form.profile_id || this.initialProfileId };
            },
        },
    },
    methods: {
        async addSkill() {
            try {
                
                const response = await axios.post('/skills', this.form);
                this.$emit('formSubmitted', response.data);               
                this.message = response.data.message;

                this.success = true;
                this.form = {
                    ...this.form,
                    name: '',
                    level: '',
                };

            } catch (error) {
                console.error('Error adding skill:', error);
            }
        },
    },
};
</script>