<template>
    <div class="d-flex gap-2 mb-2 flex-wrap">
        <span v-for="skill in skills" :key="skill.id"
            class="chip badge rounded-pill border border-dark d-flex align-items-center gap-2">
            {{ skill.name }}
            <!-- Badge 1 -->
            <span class="level badge rounded-pill border border-dark"
                :class="{ 'bg-success': skill.level >= 1, 'bg-secondary': skill.level < 1 }">
                &nbsp;&nbsp;&nbsp;
            </span>

            <!-- Badge 2 -->
            <span class="level badge rounded-pill border border-dark"
                :class="{ 'bg-success': skill.level >= 2, 'bg-secondary': skill.level < 2 }">
                &nbsp;&nbsp;&nbsp;
            </span>

            <!-- Badge 3 -->
            <span class="level badge rounded-pill border border-dark"
                :class="{ 'bg-success': skill.level >= 3, 'bg-secondary': skill.level < 3 }">
                &nbsp;&nbsp;&nbsp;
            </span>
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none text-danger"
                @click="$emit('deleteSkill', skill.id)">
                x
            </a>
        </span>
    </div>
</template>

<script>
export default {
    props: {
        skills: {
            type: Array,
            required: true,
        },
    },
};
</script>
<style scoped>
.chip {
    font-size: 18px;
    font-weight: normal;
    color: #000;
    background-color: #D9D9D999;
}

.level {
    width: 20px;
    height: 10px;
    font-size: 18px;
    background-color: lightgray;
}
</style>
