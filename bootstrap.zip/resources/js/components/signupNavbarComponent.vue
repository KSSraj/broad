<template>
    <div class="mb-5 curveNav">
        <nav class="navbar navbar-expand-lg  navbar-dark ">
            <div class="container-fluid">
                <!-- Logo -->
                <a class="navbar-brand" href="#">
                    <img :src="logoHeaderSrc" alt="Logo" height="48">
                </a>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <!-- First menu section -->

                    <!-- Right aligned nav items -->
                    <!--  Main menu -->
                    <ul class="main-menu navbar-nav ms-auto ">

                        <li class="nav-item d-flex flex-column gap-2">
                            <a class="nav-link d-flex flex-row align-items-center justify-content-center rounded-pill px-3 install-app" aria-current="page" href="#">
                                <span class="d-none d-xl-block">Install App</span>
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M21 15V16.2C21 17.8802 21 18.7202 20.673 19.362C20.3854 19.9265 19.9265 20.3854 19.362 20.673C18.7202 21 17.8802 21 16.2 21H7.8C6.11984 21 5.27976 21 4.63803 20.673C4.07354 20.3854 3.6146 19.9265 3.32698 19.362C3 18.7202 3 17.8802 3 16.2V15M17 10L12 15M12 15L7 10M12 15V3" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>

                            </a>
                        </li>

                        <li class="v-line">
                            <img :src="white_pipe_icon" alt="white pipe icon" >
                        </li>

                        <li class="nav-item d-flex flex-column gap-2">
                            <a class="nav-link d-flex flex-row align-items-center px-3 justify-content-center rounded-pill bg-yellow" aria-current="page" href="#">
                                <span class="d-none d-xl-block">Get on the Stage!</span>

                            </a>
                        </li>
                        <!-- Profile menu -->
                        <li class="nav-item dropdown gap-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12 10C14.2091 10 16 8.20914 16 6C16 3.79086 14.2091 2 12 2C9.79086 2 8 3.79086 8 6C8 8.20914 9.79086 10 12 10Z"
                                    stroke="white" stroke-opacity="0.9" stroke-width="1.5"/>
                                <path
                                    d="M19.998 18C20 17.836 20 17.669 20 17.5C20 15.015 16.418 13 12 13C7.582 13 4 15.015 4 17.5C4 19.985 4 22 12 22C14.231 22 15.84 21.843 17 21.563"
                                    stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round"/>
                            </svg>
                            <div class="d-flex flex-column">
                                <a :href="registerUrl">
                                <span class="userName pointer" > Sign up</span>
                                </a>
                            </div>
                        </li>

                        <li class="v-line">
                            <img :src="white_pipe_icon" alt="white pipe icon" >
                        </li>

                        <!-- Last menu -->
                        <li class="nav-item ">
                            <a class="nav-link " href="#" id="navbarUser" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                                <img :src="nine_dot_icon" width="32" height="32"  alt="nine dots"/>
                            </a>

                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="header-curve-div"></div>
    </div>
</template>
<script setup>
defineProps(['profileName', 'registerUrl']);
let a = null;
const profileName = "Shahrukh Khan";

</script>

<script>
export default {
    props: {
        loginUrl: {
            type: String,
            required: true
        }
    },
    data() {

        return {
            logoHeaderSrc: '/images/logo_header.svg',
            nine_dot_icon: '/images/nine-dot-icon.svg',
            white_pipe_icon: '/images/white-pipe-icon.svg',
        }
    },
    mounted() {

        console.log('Navbar mounted.')
    }
}
</script>
