<template>
    <div class="row">
        <div class="col-md-6" v-for="education in educations" :key="education.id">
            <ul>
                <li>
                    <div class="d-flex gap-3">
                        <span class="fw-bold">{{ education.year }}</span>
                        <div>{{ education.description }}</div>
                        <div class="d-flex gap-2 align-items-center">
                            <a href="javascript:;"
                                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                                @click="$emit('editEducation', education)">
                                <img class="add-icon" src="/images/edit-circle.svg" height="18" width="18" alt="Edit" />
                            </a>
                            <a href="javascript:;"
                                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                                @click="$emit('deleteEducation', education.id)">
                                <img class="add-icon" src="/images/remove-circle.svg" height="22" width="22"
                                    alt="Edit" />
                            </a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        educations: {
            type: Array,
            required: true,
        },
    },
    emits: ['editEducation', 'deleteEducation'],
};
</script>

<style scoped>
.add-icon {
    cursor: pointer;
}
</style>