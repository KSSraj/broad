<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div> Education & Training</div>
            <a href="javascript:;" v-if="educations.length > 0"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none" @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->      
        <education-list :educations="educations" @editEducation="openEditModal"
            @deleteEducation="deleteEducation" />
        <div v-if="educations.length <= 0">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="educationModal"
        :title="selectedEducation ? 'Edit Education' : 'Add Education'">
        <education-form :initial-profile-id="profileId" :initial-data="selectedEducation"
            @formSubmitted="updateEducationList" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>
import EducationList from './EducationList.vue';
import ModalComponent from '../experiences/ModalComponent.vue';
import EducationForm from './EducationForm.vue';

export default {
    components: {
        EducationList,
        ModalComponent,
        EducationForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            educations: [], // List of experiences
            selectedEducation: null, // Experience selected for editing                              
        };
    },   
    methods: {      
        // Fetch experiences from the server
        async fetchEducations() {
            try {
                const response = await axios.get(`/education/${this.profileId}`);
                this.educations = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedEducation = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList

        openEditModal(education) {
            this.selectedEducation = { ...education }; // Set experience for editing
            this.$refs.modal.showModal();
        },
        async deleteEducation(id) {
            try {
                await axios.delete(`/education/${id}`);
                this.educations = this.educations.filter((exp) => exp.id !== id); // Remove from list
            } catch (error) {
                console.error('Error deleting education:', error);
            }
        },
        // Update experiences after form submission
        updateEducationList(updatedEducation) {
            const index = this.educations.findIndex((exp) => exp.id === updatedEducation.id);
            if (index !== -1) {
                // Update existing experience
                this.educations.splice(index, 1, updatedEducation);
            } else {
                // Add new experience
                this.educations.unshift(updatedEducation);
            }
            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchEducations();
    },
};
</script>
<style scoped>

</style>