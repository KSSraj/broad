<template>
    <ul class="list-group w-100">
        <li v-for="profileLanguage in profileLanguages" :key="profileLanguage.id" class="list-group-item d-flex align-items-center">
            <!-- SVG Icon -->
            {{ profileLanguage.name }}
            <a href="javascript:;"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none text-danger"
                @click="$emit('deleteProfileLanguage', profileLanguage.id)">
                x
            </a>
        </li>
    </ul>
</template>
<script>
export default {
    props: {
        profileLanguages: {
            type: Array,
            required: true,
        },
    },
};
</script>
<style scoped></style>
