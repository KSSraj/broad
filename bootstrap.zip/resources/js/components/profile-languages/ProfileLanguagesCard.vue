<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div>Industry Focus</div>
            <a href="javascript:;" v-if="profileLanguages.length > 0"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none" @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->
        <profile-languages-list :profileLanguages="profileLanguages" @deleteProfileLanguage="deleteProfileLanguage" />
        <div v-if="profileLanguages.length <= 0">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="profileLanguageModal"
        :title="selectedProfileLanguage ? 'Edit Link' : 'Add Link'">
        <profile-languages-form :initial-profile-id="profileId" @formSubmitted="updateProfileLanguageList"
            :initial-data="selectedProfileLanguage" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>
import ProfileLanguagesList from './ProfileLanguagesList.vue';
import ModalComponent from '../experiences/ModalComponent.vue';
import ProfileLanguagesForm from './ProfileLanguagesForm.vue';

export default {
    components: {
        ProfileLanguagesList,
        ModalComponent,
        ProfileLanguagesForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            profileLanguages: [], // List of experiences
            selectedProfileLanguage: null, // Experience selected for editing                    
        };
    },
    methods: {
        // Fetch experiences from the server
        async fetchProfileLanguages() {
            try {
                const response = await axios.get(`/languages/${this.profileId}`);
                this.profileLanguages = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedProfileLanguage = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList

        async deleteProfileLanguage(id) {
            try {
                await axios.delete(`/languages/${id}`);
                this.profileLanguages = this.profileLanguages.filter((exp) => exp.id !== id); // Remove from list
            } catch (error) {
                console.error('Error deleting experience:', error);
            }
        },

        // Update experiences after form submission
        updateProfileLanguageList(updatedProfileLanguage) {     
          
            let index = -1;
            this.profileLanguages = [];
            if (updatedProfileLanguage.length > 0) {
                updatedProfileLanguage.forEach(element => {
                    index = this.profileLanguages.findIndex((language) => language.id === element.id);
                    if (index !== -1) {
                        // Update existing experience
                        this.profileLanguages.splice(index, 1, element);
                    } else {
                        // Add new experience
                        this.profileLanguages.unshift(element);
                    }
                });
            }

            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchProfileLanguages();
    },
};
</script>
<style scoped></style>