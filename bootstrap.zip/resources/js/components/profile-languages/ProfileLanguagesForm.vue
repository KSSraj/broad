<template>
    <form @submit.prevent="addProfileLanguage">
        <div class="row">
            <div class="col-md-4" v-for="language in profileAllLanguages" :key="language.id">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox"
                        :checked="form.languages && form.languages.includes(language.id)"
                        @change="toggleLanguage(language.id)" :value="language.id" :id="'language-' + language.id">
                    <label class="form-check-label" :for="'language-' + language.id">{{ language.name }}</label>
                </div>
            </div>
        </div>
        <input type="number" class="d-nones" v-model="form.profile_id" id="profile_id" name="profile_id" />
        <button type="submit" class="btn btn-success">Add Languages</button>
    </form>
    <div v-if="message" :class="{ 'success': success, 'error': !success }">
        {{ message }}
    </div>
</template>

<script>
export default {
    emits: ['formSubmitted'],
    props: {
        initialData: {
            type: Object,
            default: () => ({}),
        },
        initialProfileId: {
            type: Number,
            required: true,
            default: 0,
        }
    },
    data() {
        return {
            form: {
                profile_id: this.initialProfileId,
                languages: [],
                ...this.initialData,
            },
            message: '',
            success: false,
            profileAllLanguages: [],
        };
    },
    watch: {
        initialData: {
            deep: true,
            immediate: true,
            handler(newData) {
                // Update the form and retain profile_id
                this.form = { ...newData, profile_id: this.form.profile_id || this.initialProfileId };
            },
        },
    },
    methods: {
        async fetchProfileAllLanguages() {
            try {
                const response = await axios.get(`/languages`);
                // this.profileAllLanguages = response.data;
                if (Array.isArray(response.data)) {
                    this.profileAllLanguages = response.data;
                } else {
                    console.error('Unexpected response format:', response.data);
                    this.profileAllLanguages = [];
                }
            } catch (error) {
                console.error('Error fetching experiences:', error);
                this.profileAllLanguages = [];
            }
        },
        toggleLanguage(languageId) {
            if (!this.form.languages) {
                this.form.languages = [];
            }

            const index = this.form.languages.indexOf(languageId);
            if (index === -1) {
                this.form.languages.push(languageId);
            } else {
                this.form.languages.splice(index, 1);
            }
        },
        async addProfileLanguage() {
            try {
                
                const response = await axios.post('/languages', this.form);
                this.$emit('formSubmitted', response.data);
                this.message = response.data.message;
              
                this.success = true;
                this.form = {
                    ...this.form,
                    name: '',
                };

            } catch (error) {
                console.error('Error adding profile language:', error);
            }
        },
    },
    mounted() {
        this.fetchProfileAllLanguages();
    },
};
</script>