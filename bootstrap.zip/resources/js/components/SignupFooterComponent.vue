<template>
<hr class="mb-3 mx-4 px-1">
<div class="d-flex justify-content-between text-dark pb-4 px-4 signup-footer">

<div class="d-flex gap-3">
    <div class="">
        <a href="#" class="text-dark text-decoration-none">Privacy Policy</a>
    </div>
    <div class="">
        <a href="#" class="text-dark text-decoration-none">Terms & Conditions</a>
    </div>
    <div class="">
        <a href="#" class="text-dark text-decoration-none">Support</a>
    </div>
</div>
<div class="">
    <div class="">
        <p class="mb-0">© Copyright 2024, All Rights Reserved</p>
    </div>
</div>
</div>
</template>
<script setup lang="ts">
</script>
