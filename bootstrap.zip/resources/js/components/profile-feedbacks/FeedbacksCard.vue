<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">           
            <a href="javascript:;" v-if="feedbacks.length > 0"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none" @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->      
        <feedbacks-list :feedbacks="feedbacks" @editFeedback="openEditModal"
            @deleteFeedback="deleteFeedback" />
        <div v-if="feedbacks.length <= 0">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="feedbacksModal"
        :title="selectedFeedback ? 'Edit Feedback' : 'Add Feedback'">
        <feedbacks-form :initial-profile-id="profileId" :initial-data="selectedFeedback"
            @formSubmitted="updateFeedbackList" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>
import FeedbacksList from './FeedbacksList.vue';
import ModalComponent from '../experiences/ModalComponent.vue';
import FeedbacksForm from './FeedbacksForm.vue';

export default {
    components: {
        FeedbacksList,
        ModalComponent,
        FeedbacksForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            feedbacks: [], // List of experiences
            selectedFeedback: null, // Experience selected for editing                              
        };
    },   
    methods: {      
        // Fetch experiences from the server
        async fetchFeedbacks() {
            try {
                const response = await axios.get(`/feedback/${this.profileId}`);
                this.feedbacks = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedFeedback = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList

        openEditModal(feedback) {
            this.selectedFeedback = { ...feedback }; // Set experience for editing
            this.$refs.modal.showModal();
        },
        async deleteFeedback(id) {
            try {
                await axios.delete(`/feedback/${id}`);
                this.feedbacks = this.feedbacks.filter((exp) => exp.id !== id); // Remove from list
            } catch (error) {
                console.error('Error deleting feedback:', error);
            }
        },
        // Update experiences after form submission
        updateFeedbackList(updatedFeedback) {
            const index = this.feedbacks.findIndex((exp) => exp.id === updatedFeedback.id);
            if (index !== -1) {
                // Update existing experience
                this.feedbacks.splice(index, 1, updatedFeedback);
            } else {
                // Add new experience
                this.feedbacks.unshift(updatedFeedback);
            }
            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchFeedbacks();
    },
};
</script>
<style scoped>

</style>