<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div>My Policy</div>
            <a href="javascript:;" v-if="policies.length > 0"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none" @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->
        <policy-list :policies="policies"  @deletePolicy="deletePolicy"/>
        <div v-if="policies.length <= 0">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="policyModal" :title="selectedPolicy ? 'Edit Policy' : 'Add Policy'">
        <policy-form :initial-profile-id="profileId" @formSubmitted="updatePolicyList" :initial-data="selectedPolicy" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>
import PolicyList from './PolicyList.vue';
import ModalComponent from '../experiences/ModalComponent.vue';
import PolicyForm from './PolicyForm.vue';

export default {
    components: {
        PolicyList,
        ModalComponent,
        PolicyForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            policies: [], // List of experiences
            selectedPolicy: null, // Experience selected for editing                    
        };
    },
    methods: {
        // Fetch experiences from the server
        async fetchPolicies() {
            try {
                const response = await axios.get(`/policies/${this.profileId}/policies`);
                this.policies = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedPolicy = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList
       
        async deletePolicy(id) {
            try {
                await axios.delete(`/policies/${id}`);
                this.policies = this.policies.filter((exp) => exp.id !== id); // Remove from list
            } catch (error) {
                console.error('Error deleting experience:', error);
            }
        },

        // Update experiences after form submission
        updatePolicyList(updatedPolicy) {
            const index = this.policies.findIndex((policy) => policy.id === updatedPolicy.id);
            if (index !== -1) {
                // Update existing experience
                this.policies.splice(index, 1, updatedPolicy);
            } else {
                // Add new experience
                this.policies.unshift(updatedPolicy);
            }
            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchPolicies();
    },
};
</script>
<style scoped></style>