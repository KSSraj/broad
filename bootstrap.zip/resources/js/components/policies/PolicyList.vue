<template>
    <ul class="list-group w-100">
        <li v-for="policy in policies" :key="policy.id" class="list-group-item d-flex align-items-center">
            <!-- SVG Icon -->
            {{ policy.name }}
            <a href="javascript:;"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none text-danger"
                @click="$emit('deletePolicy', policy.id)">
                x
            </a>
        </li>
    </ul>
</template>
<script>
export default {
    props: {
        policies: {
            type: Array,
            required: true,
        },
    },
};
</script>
<style scoped></style>
