<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div>Honors & awards</div>
            <a href="javascript:;" v-if="awards.length > 0"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none" @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->      
        <profile-awards-list :awards="awards" @editAward="openEditModal"
            @deleteAward="deleteAward" />
        <div v-if="awards.length <= 0">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="awardModal"
        :title="selectedAward ? 'Edit Award' : 'Add Award'">
        <profile-awards-form :initial-profile-id="profileId" :initial-data="selectedAward"
            @formSubmitted="updateAwardsList" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>
import ProfileAwardsList from './ProfileAwardsList.vue';
import ModalComponent from '../experiences/ModalComponent.vue';
import ProfileAwardsForm from './ProfileAwardsForm.vue';

export default {
    components: {
        ProfileAwardsList,
        ModalComponent,
        ProfileAwardsForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            awards: [], // List of experiences
            selectedAward: null, // Experience selected for editing                              
        };
    },   
    methods: {      
        // Fetch experiences from the server
        async fetchAwards() {
            try {
                const response = await axios.get(`/award/${this.profileId}`);
                this.awards = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedAward = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList

        openEditModal(award) {
            this.selectedAward = { ...award }; // Set experience for editing
            this.$refs.modal.showModal();
        },
        async deleteAward(id) {
            try {
                await axios.delete(`/award/${id}`);
                this.awards = this.awards.filter((exp) => exp.id !== id); // Remove from list
            } catch (error) {
                console.error('Error deleting education:', error);
            }
        },
        // Update experiences after form submission
        updateAwardsList(updatedAward) {
            const index = this.awards.findIndex((exp) => exp.id === updatedAward.id);
            if (index !== -1) {
                // Update existing experience
                this.awards.splice(index, 1, updatedAward);
            } else {
                // Add new experience
                this.awards.unshift(updatedAward);
            }
            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchAwards();
    },
};
</script>
<style scoped>

</style>