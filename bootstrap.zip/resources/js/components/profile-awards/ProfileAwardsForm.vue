<template>
    <form @submit.prevent="submitForm">
        <div class="form-group">
            <label for="details" class="form-label">Award Name</label>
            <input class="form-control" name="description" v-model="form.award_name" id="award_name"/>
        </div>  
        <div class="form-group">
            <label for="details" class="form-label">Award Details</label>
            <textarea class="form-control" name="description" v-model="form.description" id="description"></textarea>
        </div>           
        <div class="form-group">
            <label for="year" class="form-label">Year</label>
            <input class="form-control" type="number" name="year" v-model="form.year" id="year" required>
            <!-- <input type="hidden" name="education_id" v-model="form.award_id" id="award_id"> -->
        </div>
        <button type="submit" class="btn btn-success my-2"> {{ form.id ? 'Update' : 'Save' }}</button>       
    </form>
    <div v-if="message" :class="{ 'success': success, 'error': !success }">
        {{ message }}
    </div>
</template>
<script>
import axios from 'axios';
export default {
    emits: ['formSubmitted'],
    props: {
        initialData: {
            type: Object,
            default: () => ({}),
        },
        initialProfileId: {
            type: Number,
            required: true,
            default: 0,
        },
    },
    data() {        
        return {            
            form: { 
                profile_id: this.initialProfileId, 
                ...this.initialData 
            },
            message: '',
            success: false,
        };
    },
    watch: {
        initialData: {
            deep: true,
            immediate: true,
            handler(newData) {
                // Update the form and retain profile_id
                this.form = { ...newData, profile_id: this.form.profile_id || this.initialProfileId };
            },
        },
    },
    methods: {
        async submitForm() {
            try {
                const url = this.form.id
                    ? `/award/${this.form.id}`
                    : '/award';
                const method = this.form.id ? 'put' : 'post';

                const response = await axios[method](url, this.form);
                this.$emit('formSubmitted', response.data);

                this.message = response.data.message;
                this.success = true;
                this.form = {
                    ...this.form,                                                    
                };

                setTimeout(() => {
                    this.successMessage = '';
                }, 3000);

            } catch (error) {
                this.message = error.response?.data?.message || 'An error occurred.';
                this.success = false;
            }
        },
    },
};
</script>

<style>
.success {
    color: green;
}

.error {
    color: red;
}
</style>
