<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div>Attributes</div>
            <a href="javascript:;" v-if="attributes"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openEditModal(attributes)">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->
        <profile-attributes :profileAttributes="attributes || null" />
        <div v-if="!attributes">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openEditModal(attributes)">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="attributesModal" :title="attributes ? 'Edit Attributes' : 'Add Attributes'">
        <profile-attributes-form :initial-profile-id="profileId" @formSubmitted="updateAttributes" :initial-data="attributes" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>

import ModalComponent from '../experiences/ModalComponent.vue';
import ProfileAttributes from './ProfileAttributes.vue';
import ProfileAttributesForm from './ProfileAttributesForm.vue';

export default {
    components: {
        ProfileAttributes,
        ModalComponent,
        ProfileAttributesForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            attributes: [], // List of experiences
            selectedAttribute: Object, // Experience selected for editing                    
        };
    },
    methods: {
        // Fetch experiences from the server
        async fetchAttributes() {
            try {
                const response = await axios.get(`/profiles/${this.profileId}/attributes`);
                this.attributes = response.data;                
            } catch (error) {
                console.error('Error fetching attributes:', error);
            }
        },
        openAddModal() {
            this.selectedAttribute = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList

        openEditModal(attributes) {           
            this.attributes = attributes; // Set experience for editing
            this.$refs.modal.showModal();
        },

        // Update experiences after form submission
        updateAttributes(updatedAttribute) {
            this.attributes = updatedAttribute;
            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchAttributes();
    },
};
</script>
<style scoped></style>