<template>   
    <div class="d-flex justify-content-between gap-2" v-for="attribute in profileAttributes">
        <div class="mb-1">{{ attribute.attribute_key }}</div>
        <div class="mb-1">{{ attribute.attribute_value }}</div>
    </div>  
</template>
<script>
export default {
    props: {
        profileAttributes: {
            type: [Array, null],
            required: true,          
        },
    },
};
</script>
<style scoped></style>
