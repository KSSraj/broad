<template>
    <form @submit.prevent="addAttributes">
        <div class="form-group">
            <label for="height">Height:</label>
            <input type="number" class="form-control" id="height" placeholder="e.g. 5.5" name="height" step="0.1"
                v-model="form.Height">
        </div>
        <div class="form-group">
            <label for="weight">Weight:</label>
            <input type="number" class="form-control" id="weight" placeholder="E.g 55" name="weight" step="0.1"
                v-model="form.Weight">
        </div>
        <div class="form-group">
            <label for="build">Build:</label>
            <input type="text" class="form-control" id="build" placeholder="E.g Average" name="build"
                v-model="form.Build">
        </div>
        <div class="form-group">
            <label for="hair">Hair:</label>
            <input type="text" class="form-control" id="hair" placeholder="E.g Black" name="hair" v-model="form.Hair">
        </div>
        <div class="form-group">
            <label for="eyes">Eyes:</label>
            <input type="text" class="form-control" id="eyes" placeholder="E.g Eyes" name="eyes" v-model="form.Eyes">
        </div>
        <div class="form-group">
            <label for="skin">Skin:</label>
            <input type="text" class="form-control" id="skin" placeholder="E.g Black" name="skin" v-model="form.Skin">
            <input type="hidden" class="form-control" id="profile_id" value="{{session('profileId')}}">
        </div>
        <input type="number" class="d-nones" v-model="form.profile_id" id="profile_id" name="profile_id" />
        <button type="submit" class="btn btn-success">Update</button>
    </form>
    <div v-if="message" :class="{ 'success': success, 'error': !success }">
        {{ message }}
    </div>
</template>

<script>
export default {
    emits: ['formSubmitted'],
    props: {
        initialData: {
            type: Array,
            default: () => [{}],
        },
        initialProfileId: {
            type: Number,
            required: true,
            default: 0,
        },
    },
    data() {
        return {
            form: {
                profile_id: this.initialProfileId,
                ...this.transformInitialData(this.initialData),
            },
            message: '',
            success: false,
        };
    },
    watch: {
        initialData: {
            deep: true,
            immediate: true,
            handler(newData) {
                // Update the form and retain profile_id               
                this.form = {
                    ...this.form,
                    ...this.transformInitialData(newData),
                    profile_id: this.form.profile_id || this.initialProfileId
                };
            },
        },
    },
    methods: {
        transformInitialData(data) {
            // Convert initialData array into an object for easier handling
            return data.reduce((acc, item) => {
                acc[item.attribute_key] = item.attribute_value;
                return acc;
            }, {});
        },
        async addAttributes() {
            try {
            
                const response = await axios.post(`/attributes`, this.form);
                this.$emit('formSubmitted', response.data);
                this.message = response.data.message;

                this.success = true;
                this.form = {
                    ...this.form,
                };

            } catch (error) {
                this.message = 'Failed to update the profile. Please try again.';
                this.success = false;
            }
        },
    },
};
</script>