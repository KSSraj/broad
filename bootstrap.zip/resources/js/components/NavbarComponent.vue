<template>
    <div class="mb-5 curveNav">
        <nav class="navbar navbar-expand-lg  navbar-dark ">
            <div class="container-fluid">
                <!-- Logo -->
                <a class="navbar-brand" href="#">
                    <img :src="logoHeaderSrc" alt="Logo" height="48">
                </a>
                <!-- Toggle button -->
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                <!-- First menu section -->
                    <ul class="d-flex navbar-nav gap-1  justify-content-xxl-evenly search-box-div">
                        <li class="nav-item dropdown m-0 me-xl-3">
                            <a class="nav-link " href="#" id="navbarUser" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                                <img src="/images/search-icon.svg" alt="Search icon" />
                            </a>
                            <div class="dropdown-menu header-search-div">

                                <form class="d-flex" action="/search">
                                    <input name="q" class="form-control me-2" type="search" placeholder="Search"
                                           aria-label="Search">
                                    <button class="btn btn-info" type="submit">Search</button>
                                </form>

                            </div>
                        </li>
                        <!-- industry insights menu -->
                        <li>
                            <a href="#"  class="d-flex align-items-center gap-1 gap-lg-2 gap-xxl-3">
                            <img :src="bulbIcon" alt="bulbicon" height="32" width="32">

                            <svg class="d-xxl-block d-none" width="2" height="40" viewBox="0 0 2 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect width="1" height="40" rx="0.5" transform="matrix(-1 0 0 1 1.38574 0)" fill="white" fill-opacity="0.9"/>
                            </svg>
                            <span class="text-uppercase insight-text d-xl-block d-none">Industry<br>Insights</span>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M0.435547 14L5.43555 7L0.435547 0H2.88555L7.88555 7L2.88555 14H0.435547ZM6.38555 14L11.3855 7L6.38555 0H8.83555L13.8355 7L8.83555 14H6.38555Z" fill="white" fill-opacity="0.9"/>
                            </svg>
                            </a>
                        </li>
                    </ul>
                    <!-- Right aligned nav items -->
                    <!--  Main menu -->
                    <ul class="main-menu navbar-nav ms-auto ">
                        <li class="nav-item  active">
                            <a class="nav-link p-0 d-flex flex-column align-items-center gap-1" aria-current="page" href="#">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M10 16H14M2 7.99998L11.732 3.13398C11.8152 3.09243 11.907 3.0708 12 3.0708C12.093 3.0708 12.1848 3.09243 12.268 3.13398L22 7.99998M20 11V19C20 19.5304 19.7893 20.0391 19.4142 20.4142C19.0391 20.7893 18.5304 21 18 21H6C5.46957 21 4.96086 20.7893 4.58579 20.4142C4.21071 20.0391 4 19.5304 4 19V11"
                                    stroke="#FFFFFF" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                                <span class="d-none d-xl-block">  Home</span>


                            </a>
                        </li>
                        <li class="nav-item d-flex flex-column gap-1">
                            <a class="nav-link p-0 d-flex flex-column align-items-center gap-1" aria-current="page" href="#">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M17.8877 10.8967C19.2827 10.7007 20.3567 9.50473 20.3597 8.05573C20.3597 6.62773 19.3187 5.44373 17.9537 5.21973"
                                    stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round"
                                    stroke-linejoin="round"/>
                                <path
                                    d="M19.7285 14.2505C21.0795 14.4525 22.0225 14.9255 22.0225 15.9005C22.0225 16.5715 21.5785 17.0075 20.8605 17.2815"
                                    stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round"
                                    stroke-linejoin="round"/>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                      d="M11.8867 14.6638C8.67273 14.6638 5.92773 15.1508 5.92773 17.0958C5.92773 19.0398 8.65573 19.5408 11.8867 19.5408C15.1007 19.5408 17.8447 19.0588 17.8447 17.1128C17.8447 15.1668 15.1177 14.6638 11.8867 14.6638Z"
                                      stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round"
                                      stroke-linejoin="round"/>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                      d="M11.8869 11.888C13.9959 11.888 15.7059 10.179 15.7059 8.069C15.7059 5.96 13.9959 4.25 11.8869 4.25C9.7779 4.25 8.0679 5.96 8.0679 8.069C8.0599 10.171 9.7569 11.881 11.8589 11.888H11.8869Z"
                                      stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round"
                                      stroke-linejoin="round"/>
                                <path
                                    d="M5.88509 10.8967C4.48909 10.7007 3.41609 9.50473 3.41309 8.05573C3.41309 6.62773 4.45409 5.44373 5.81909 5.21973"
                                    stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round"
                                    stroke-linejoin="round"/>
                                <path
                                    d="M4.044 14.2505C2.693 14.4525 1.75 14.9255 1.75 15.9005C1.75 16.5715 2.194 17.0075 2.912 17.2815"
                                    stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round"
                                    stroke-linejoin="round"/>
                            </svg>
                                <span class="d-none d-xl-block">Connections</span>
                            </a>
                        </li>
                        <li class="nav-item d-flex flex-column gap-1">
                            <a class="nav-link p-0 d-flex flex-column align-items-center gap-1" aria-current="page" href="#">
                            <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M6.5 11H12.5M6.5 7H9.5M7.5 19C8.55 19.87 9.815 20.424 11.264 20.519C12.405 20.594 13.597 20.594 14.737 20.519C15.1444 20.4908 15.545 20.4004 15.925 20.251C16.335 20.084 16.539 20.001 16.644 20.014C16.748 20.026 16.899 20.136 17.201 20.356C17.734 20.744 18.405 21.022 19.401 20.999C19.904 20.987 20.156 20.98 20.268 20.791C20.381 20.601 20.241 20.339 19.96 19.814C19.57 19.086 19.324 18.253 19.698 17.585C20.341 16.631 20.888 15.502 20.968 14.282C21.011 13.627 21.011 12.948 20.968 12.292C20.9159 11.5004 20.7235 10.7243 20.4 10" stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M11.345 16.487C14.901 16.253 17.733 13.407 17.965 9.834C18.011 9.135 18.011 8.411 17.965 7.712C17.733 4.14 14.901 1.294 11.345 1.06C10.132 0.98 8.86499 0.98 7.65499 1.06C4.09899 1.294 1.26699 4.14 1.03499 7.712C0.988988 8.412 0.988988 9.135 1.03499 9.834C1.11899 11.136 1.69999 12.34 2.38399 13.358C2.78099 14.07 2.51899 14.958 2.10499 15.735C1.80699 16.295 1.65799 16.575 1.77799 16.777C1.89799 16.979 2.16499 16.986 2.69999 16.998C3.75699 17.024 4.46999 16.727 5.03599 16.313C5.35699 16.079 5.51799 15.962 5.62899 15.948C5.73899 15.935 5.95699 16.023 6.39199 16.201C6.78399 16.361 7.23799 16.459 7.65499 16.487C8.86499 16.567 10.132 16.567 11.345 16.487Z" stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>


                                <span class="d-none d-xl-block">Messages</span>
                            </a>
                        </li>

                        <li class="nav-item d-flex flex-column gap-1">
                            <a class="nav-link p-0 d-flex flex-column align-items-center gap-1" aria-current="page" href="#">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M12 17.8476C17.6392 17.8476 20.2481 17.1242 20.5 14.2205C20.5 11.3188 18.6812 11.5054 18.6812 7.94511C18.6812 5.16414 16.0452 2 12 2C7.95477 2 5.31885 5.16414 5.31885 7.94511C5.31885 11.5054 3.5 11.3188 3.5 14.2205C3.75295 17.1352 6.36177 17.8476 12 17.8476Z" stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M14.3889 20.8572C13.0247 22.3719 10.8967 22.3899 9.51953 20.8572" stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>

                                <span class="d-none d-xl-block">Notifications</span>

                            </a>
                        </li>

                        <li class="v-line">
                            <img :src="white_pipe_icon" alt="white pipe icon" >
                        </li>
                        <!-- Profile menu -->
                        <li class="nav-item dropdown gap-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12 10C14.2091 10 16 8.20914 16 6C16 3.79086 14.2091 2 12 2C9.79086 2 8 3.79086 8 6C8 8.20914 9.79086 10 12 10Z"
                                    stroke="white" stroke-opacity="0.9" stroke-width="1.5"/>
                                <path
                                    d="M19.998 18C20 17.836 20 17.669 20 17.5C20 15.015 16.418 13 12 13C7.582 13 4 15.015 4 17.5C4 19.985 4 22 12 22C14.231 22 15.84 21.843 17 21.563"
                                    stroke="white" stroke-opacity="0.9" stroke-width="1.5" stroke-linecap="round"/>
                            </svg>
                            <div class="d-flex flex-column">
                                <span class="userName pointer" :title="profileName"> {{ profileName }}</span>
                                <em><span class="span-profile-as">Actor / Performer </span></em>
                            </div>
                            <a class="nav-link px-0" href="#" id="navbarLang" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6 9L12 15L18 9" stroke="white" stroke-opacity="0.9" stroke-width="2"
                                          stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>

                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarUser">
                                <li><a class="dropdown-item" href="#">Profile</a></li>
                                <li><a class="dropdown-item" href="#">Sign Out</a></li>
                            </ul>

                        </li>

                        <li class="v-line">
                            <img :src="white_pipe_icon" alt="white pipe icon" >
                        </li>

                        <!-- Last menu -->
                        <li class="nav-item ">
                            <a class="nav-link " href="#" id="navbarUser" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                               <img :src="nine_dot_icon" width="32" height="32"  alt="nine dots"/>
                            </a>

                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="header-curve-div"></div>
    </div>
</template>
<script setup>
defineProps(['profileName']);
let a = null;
const profileName = "Shahrukh Khan";
</script>

<script>
export default {
    data() {
        return {
            logoHeaderSrc: '/images/logo_header.svg',
            nine_dot_icon: '/images/nine-dot-icon.svg',
            bulbIcon: '/images/bulb-icon.svg',
            white_pipe_icon: '/images/white-pipe-icon.svg',

        }
    },
    mounted() {

        console.log('Navbar mounted.')
    }
}
</script>
