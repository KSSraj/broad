<template>
    <ul class="list-group w-100">
        <li v-for="document in documents" :key="document.id" class="list-group-item d-flex align-items-center">
            <!-- SVG Icon -->
            {{ document.is_available }} {{ document.name }}
            <a href="javascript:;"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none text-danger"
                @click="$emit('deleteDocument', document.id)">
                x
            </a>
        </li>
    </ul>
</template>
<script>
export default {
    props: {
        documents: {
            type: Array,
            required: true,
        },
    },
};
</script>
<style scoped></style>
