<template>
    <form @submit.prevent="addDocument">
        <div class="list-group">
            <label class="list-group-item">
                <input class="form-check-input me-1" type="checkbox" name="driving_licence"
                    v-model="form.driving_licence">
                Driving License
            </label>
            <label class="list-group-item">
                <input class="form-check-input me-1" type="checkbox" name="passport" v-model="form.passport">
                Passport
            </label>
            <label class="list-group-item">
                <input class="form-check-input me-1" type="checkbox" name="resume" v-model="form.resume">
                Resume
            </label>
        </div>
        <input type="number" class="d-nones" v-model="form.profile_id" id="profile_id" name="profile_id" />
        <button type="submit" class="btn btn-success">Add Document</button>
    </form>
    <div v-if="message" :class="{ 'success': success, 'error': !success }">
        {{ message }}
    </div>
</template>

<script>
export default {
    emits: ['formSubmitted'],
    props: {
        initialData: {
            type: Object,
            default: () => ({}),
        },
        initialProfileId: {
            type: Number,
            required: true,
            default: 0,
        },
    },
    data() {
        return {
            form: {
                profile_id: this.initialProfileId,
                ...this.initialData
            },
            message: '',
            success: false,
        };
    },
    watch: {
        initialData: {
            deep: true,
            immediate: true,
            handler(newData) {
                // Update the form and retain profile_id
                this.form = { ...newData, profile_id: this.form.profile_id || this.initialProfileId };
            },
        },
    },
    methods: {
        async addDocument() {
            try {

                const response = await axios.post('/documents', this.form);               
                this.$emit('formSubmitted', response.data);
                this.message = response.data.message;

                this.success = true;
                this.form = {
                    ...this.form,
                    driving_licence: '',
                    passport: '',
                    resume: '',
                };

            } catch (error) {
                console.error('Error adding skill:', error);
            }
        },
    },
};
</script>