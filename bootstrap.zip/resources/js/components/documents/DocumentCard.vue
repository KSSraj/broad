<template>
    <div class="card-title text-left">
        <div class="d-flex align-items-center justify-content-between gap-2">
            <div>Documents</div>
            <a href="javascript:;" v-if="documents.length > 0"
                class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none" @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Filter Chips -->
        <document-list :documents="documents" @deleteDocument="deleteDocument" />
        <div v-if="documents.length <= 0">
            <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                @click="openAddModal">
                <img class="add-icon" src="/images/add-circle.svg" height="20" width="20" alt="">
                <span>Add</span>
            </a>
        </div>
    </div>
    <modal-component ref="modal" modalId="documentModal" :title="selectedDocument ? 'Edit Document' : 'Add Document'">
        <document-form :initial-profile-id="profileId" @formSubmitted="updateDocumentList"
            :initial-data="selectedDocument" />
    </modal-component>
    <!-- Pass the experiences data as a prop to ExperienceList -->
</template>

<script>
import DocumentList from './DocumentList.vue';
import ModalComponent from '../experiences/ModalComponent.vue';
import DocumentForm from './DocumentForm.vue';

export default {
    components: {
        DocumentList,
        ModalComponent,
        DocumentForm,
    },
    props: {
        profileId: {
            type: [String, Number],
            required: true
        }
    },
    data() {
        return {
            documents: [], // List of experiences
            selectedDocument: null, // Experience selected for editing                    
        };
    },
    methods: {
        // Fetch experiences from the server
        async fetchDocuments() {
            try {
                const response = await axios.get(`/documents/${this.profileId}`);
                this.documents = response.data;
            } catch (error) {
                console.error('Error fetching experiences:', error);
            }
        },
        openAddModal() {
            this.selectedDocument = null; // Clear selection for adding
            this.$refs.modal.showModal();
        },
        // Handle edit event from ExperienceList

        openEditModal(document) {
            this.selectedDocument = { ...document }; // Set experience for editing
            this.$refs.modal.showModal();
        },
        async deleteDocument(id) {
            try {
                await axios.delete(`/document/${id}`);
                this.documents = this.documents.filter((exp) => exp.id !== id); // Remove from list
            } catch (error) {
                console.error('Error deleting experience:', error);
            }
        },

        // Update experiences after form submission
        updateDocumentList(updatedDocument) {            
            let index = -1;
            if (updatedDocument.length > 0) {
                updatedDocument.forEach(element => {
                    index = this.documents.findIndex((document) => document.id === element.id);
                    if (index !== -1) {
                        // Update existing experience
                        this.documents.splice(index, 1, element);
                    } else {
                        // Add new experience
                        this.documents.unshift(element);
                    }
                });
            }

            this.$refs.modal.closeModal(); // Close the modal after update
        },
    },
    mounted() {
        this.fetchDocuments();
    },
};
</script>
<style scoped></style>