/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

import './bootstrap';

import { createApp } from 'vue';
import jQuery from 'jquery';
window.$ = jQuery;

/**
 * Next, we will create a fresh Vue application instance. You may then begin
 * registering components with the application instance so they are ready
 * to use in your application's views. An example is included for you.
 */

const app = createApp({});

import ExampleComponent from './components/ExampleComponent.vue';
import NavbarComponent from './components/NavbarComponent.vue';
import NavbarWithoutMenuComponent from './components/NavbarWithoutMenuComponent.vue';
import SignupNavbarComponent from "./components/signupNavbarComponent.vue";
import SignupFooterComponent from "./components/SignupFooterComponent.vue";
 
import ProfileExperienceCard from "./components/experiences/ProfileExperienceCard.vue";
import ProfileSkillCard from "./components/skills/ProfileSkillCard.vue";
import PolicyCard from "./components/policies/PolicyCard.vue";
import DocumentCard from "./components/documents/DocumentCard.vue";
import SocialLinksCard from "./components/social-links/SocialLinksCard.vue";
import ProfileLanguagesCard from "./components/profile-languages/ProfileLanguagesCard.vue";
import EducationCard from "./components/education/EducationCard.vue";
import AboutMeCard from "./components/about-me/AboutMeCard.vue";
import ProfileAttributesCard from "./components/attributes/ProfileAttributesCard.vue";
import ProfileAwardsCard from "./components/profile-awards/ProfileAwardsCard.vue";
import HighlightsCard from "./components/profile-highlights/HighlightsCard.vue";
import FeedbacksCard from "./components/profile-feedbacks/FeedbacksCard.vue";

app.component('example-component', ExampleComponent);
app.component('navbar-component', NavbarComponent);
app.component('navbar-without-menu-component', NavbarWithoutMenuComponent);
app.component('signup-navbar-component', SignupNavbarComponent);
app.component('signup-footer-component', SignupFooterComponent);

app.component('profile-experience-card', ProfileExperienceCard);
app.component('profile-skill-card', ProfileSkillCard);
app.component('policy-card', PolicyCard);
app.component('document-card', DocumentCard);
app.component('social-links-card', SocialLinksCard);
app.component('profile-languages-card', ProfileLanguagesCard);
app.component('profile-education-card', EducationCard);
app.component('about-me-card', AboutMeCard);
app.component('profile-attributes-card', ProfileAttributesCard);
app.component('profile-awards-card', ProfileAwardsCard);
app.component('profile-highlights-card', HighlightsCard);
app.component('profile-feedbacks-card', FeedbacksCard);
/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// Object.entries(import.meta.glob('./**/*.vue', { eager: true })).forEach(([path, definition]) => {
//     app.component(path.split('/').pop().replace(/\.\w+$/, ''), definition.default);
// });

/**
 * Finally, we will attach the application instance to a HTML element with
 * an "id" attribute of "app". This element is included with the "auth"
 * scaffolding. Otherwise, you will need to add an element yourself.
 */

app.mount('#app');
