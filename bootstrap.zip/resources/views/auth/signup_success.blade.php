
@extends('layouts.signup_layout')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="mt-5 text-center">

                     <img src="/images/success.png" alt="success" width="479.36px">
                    <h1 class="display-text">Let’s grab your Opportunity </h1>
                    <p>Welcome on the BroadStage Networks</p>
                    <a class="continue-button-general m-auto text-center" href="/profile/step/2"> Set up your Profile</a>

                </div>
            </div>
        </div>
    </div>
@endsection
