@extends('layouts.app')

@section('content')
    <div class="container-fluid bg-black p-0">
        <div class="signup-bg d-flex">

            <div class="w-50 ms-auto">
                <div class="signup-left-wrapper">
                    <h1>Connecting Talent to Opportunities</h1>
                    <br>
                    <p class="text-white-50">
                        Discover endless opportunities,<br> where talented freelancers and businesses unite. Just, Jump
                        on the <strong>Broad Stage</strong>!
                    </p>
                </div>
            </div>
            <div class="w-50 ms-auto">
                <div class="card singup-form-wrap">
                    <div class="card-body p-0 signup-custom-margin">
                        <img class="mb-4" src="/images/logo.svg" alt="logo" height="58.6">

                        <form method="POST" action="{{ route('post.signup',['id'=>($id+1)]) }}">
                            @csrf

                            <div class="row mb-3">

                                <div class="col-md-8 mt-4 pt-3">
                                    <h2 class="h2"> Email Verification</h2>
                                    <p class="mt-3">The verification code has been sent to your email </br>
                                        <strong>Jason012@gmail.com</strong></p>
                                </div>

                                <div class="col-md-8">
                                    <label for="email" class=" col-form-label ">{{ __('Email Address') }}</label>
                                    <div class="input-group">

                                        <input id="email" type="email" placeholder="your_mail_id@email.com"
                                               class="form-control border-end-0 @error('email') is-invalid @enderror"
                                               name="email"
                                               value="Jason012@gmail.com" required autocomplete="email">
                                        <span class="input-group-text" id="basic-addon2">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                 xmlns="http://www.w3.org/2000/svg">
                                                <path d="M12 4.00009H6C4.89543 4.00009 4 4.89552 4 6.00009V18.0001C4 19.1047 4.89543 20.0001 6 20.0001H18C19.1046 20.0001 20 19.1047 20 18.0001V12.0001M18.4142 8.4143L19.5 7.32854C20.281 6.54749 20.281 5.28117 19.5 4.50012C18.7189 3.71907 17.4526 3.71907 16.6715 4.50013L15.5858 5.58587M18.4142 8.4143L12.3779 14.4507C12.0987 14.7299 11.7431 14.9202 11.356 14.9976L8.41422 15.586L9.00257 12.6442C9.08001 12.257 9.27032 11.9014 9.54951 11.6222L15.5858 5.58587M18.4142 8.4143L15.5858 5.58587"
        stroke="#566AE9" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                        </span>
                                    </div>
                                    @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>


                                <div class="col-md-8 mt-3">
                                    <label for="email" class=" col-form-label ">{{ __('Enter OTP') }}</label>
                                    <div class="otp-container gap-3">
                                        <input type="text" name="otp[]" maxlength="1" class="otp-input" id="otp1" onkeyup="moveToNext(this, 'otp2')" onkeydown="moveToPrevious(event, 'otp1', null)" />
                                        <input type="text" name="otp[]" maxlength="1" class="otp-input" id="otp2" onkeyup="moveToNext(this, 'otp3')" onkeydown="moveToPrevious(event, 'otp2', 'otp1')" />
                                        <input type="text" name="otp[]" maxlength="1" class="otp-input" id="otp3" onkeyup="moveToNext(this, 'otp4')" onkeydown="moveToPrevious(event, 'otp3', 'otp2')" />
                                        <input type="text" name="otp[]" maxlength="1" class="otp-input" id="otp4" onkeyup="moveToNext(this, null)" onkeydown="moveToPrevious(event, 'otp4', 'otp3')" />
                                    </div>
                                </div>

                                <div class="col-md-8 mt-2">
                                    <div class="alert alert-info d-flex gap-2 rounded-0 border-0">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2.25C10.0716 2.25 8.18657 2.82183 6.58319 3.89317C4.97982 4.96451 3.73013 6.48726 2.99218 8.26884C2.25422 10.0504 2.06114 12.0108 2.43735 13.9021C2.81355 15.7934 3.74215 17.5307 5.10571 18.8943C6.46928 20.2579 8.20656 21.1865 10.0979 21.5627C11.9892 21.9389 13.9496 21.7458 15.7312 21.0078C17.5127 20.2699 19.0355 19.0202 20.1068 17.4168C21.1782 15.8134 21.75 13.9284 21.75 12C21.7473 9.41498 20.7192 6.93661 18.8913 5.10872C17.0634 3.28084 14.585 2.25273 12 2.25ZM12 20.25C10.3683 20.25 8.77326 19.7661 7.41655 18.8596C6.05984 17.9531 5.00242 16.6646 4.378 15.1571C3.75358 13.6496 3.5902 11.9908 3.90853 10.3905C4.22685 8.79016 5.01259 7.32015 6.16637 6.16637C7.32016 5.01259 8.79017 4.22685 10.3905 3.90852C11.9909 3.59019 13.6497 3.75357 15.1571 4.37799C16.6646 5.00242 17.9531 6.05984 18.8596 7.41655C19.7661 8.77325 20.25 10.3683 20.25 12C20.2475 14.1873 19.3775 16.2843 17.8309 17.8309C16.2843 19.3775 14.1873 20.2475 12 20.25ZM13.5 16.5C13.5 16.6989 13.421 16.8897 13.2803 17.0303C13.1397 17.171 12.9489 17.25 12.75 17.25C12.3522 17.25 11.9706 17.092 11.6893 16.8107C11.408 16.5294 11.25 16.1478 11.25 15.75V12C11.0511 12 10.8603 11.921 10.7197 11.7803C10.579 11.6397 10.5 11.4489 10.5 11.25C10.5 11.0511 10.579 10.8603 10.7197 10.7197C10.8603 10.579 11.0511 10.5 11.25 10.5C11.6478 10.5 12.0294 10.658 12.3107 10.9393C12.592 11.2206 12.75 11.6022 12.75 12V15.75C12.9489 15.75 13.1397 15.829 13.2803 15.9697C13.421 16.1103 13.5 16.3011 13.5 16.5ZM10.5 7.875C10.5 7.6525 10.566 7.43499 10.6896 7.24998C10.8132 7.06498 10.9889 6.92078 11.1945 6.83564C11.4001 6.75049 11.6263 6.72821 11.8445 6.77162C12.0627 6.81502 12.2632 6.92217 12.4205 7.0795C12.5778 7.23684 12.685 7.43729 12.7284 7.65552C12.7718 7.87375 12.7495 8.09995 12.6644 8.30552C12.5792 8.51109 12.435 8.68679 12.25 8.8104C12.065 8.93402 11.8475 9 11.625 9C11.3266 9 11.0405 8.88147 10.8295 8.6705C10.6185 8.45952 10.5 8.17337 10.5 7.875Z" fill="#605DEC"></path></svg>
                                        <span>Enter the verification code we just sent on your registered email address. </span>
                                    </div>
                                    <div class="mt-2 d-flex justify-content-between resend_otp_div">
                                        <div>Didn’t get the code? <a href="javascript:;" onclick="resendOtp()"> Resend</a> </div>
                                        <div>Expires in <span id="timer">00</span> Sec</div>
                                    </div>
                                </div>

                            </div>

                            <div class="row mt-4 pt-2">
                                <div class="col-md-8  align-items-center d-flex justify-content-between pe-1">
                                    <a href="{{ route('signup',['id'=>($id-1)]) }}" class="text-dark back-button">
                                        {{ __('Back') }}
                                    </a>
                                    <button type="submit" class="continue-btn">
                                        {{ __('Continue') }}
                                        <img src="/images/left-arrow.svg" alt="left arraow">
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- Footer -->
                    <signup-footer-component></signup-footer-component>
                </div>

            </div>

        </div>
    </div>
    <script>
        function moveToNext(current, nextFieldID) {
            current.value = current.value.trim();
            if (!isNaN(current.value)) {
                if(current.value.length >= 1 && nextFieldID) {
                    document.getElementById(nextFieldID).focus();
                }
            } else {
                // Optionally, you can clear the invalid input or give feedback
                current.value = '';  // Clear invalid input
            }
        }
        function moveToPrevious(event, currentFieldID, prevFieldID) {
            if (event.key === 'Backspace' && document.getElementById(currentFieldID).value === '' && prevFieldID) {
                document.getElementById(prevFieldID).focus();
            }
        }

        let  setTime = 180;
        let  timeLeft =setTime;
         let  timerInterval;
        function resendOtp(){
            timeLeft = setTime;
            startTimer();
        }
        function startTimer() {
            if (timerInterval) return; // Prevent starting multiple timers

            timerInterval = setInterval(function() {
                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    document.getElementById("timer").innerHTML = timeLeft;
                } else {
                    document.getElementById("timer").innerHTML = timeLeft;
                    timeLeft--;
                }
            }, 1000); // 1000ms = 1 second
        }
        startTimer();
    </script>
@endsection
