@extends('layouts.signup_layout')

@section('content')
<div class="container">
    <div class="row w-100">
        <div class="col-md-6 border-end">
            <!-- Login Section -->
            <h2 class="mb-4">Login</h2>
            <form method="POST" action="{{ route('login') }}" id="loginForm">
                @csrf
                <div class="mb-3">
                    <label for="email" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group mb-3">
                        <input type="password" class="form-control" id="password" name="password"
                            placeholder="Enter your password">
                        <span class="input-group-text" id="togglePassword">
                            <i class="bi bi-eye-fill fs-5" style="cursor: pointer" id="togglePasswordIcon"></i>
                        </span>
                    </div>


                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="rememberMe">
                    <label class="form-check-label" for="rememberMe">Remember me</label>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <button type="submit" class="btn btn-dark">Login<span id="loginspinner"
                            class="spinner-border spinner-border-sm d-none" role="status"
                            aria-hidden="true"></span></button>

                    @if (Route::has('password.request'))
                        <a class="btn btn-link" href="{{ route('password.request') }}">
                            {{ __('Forgot Password?') }}
                        </a>
                    @endif
                </div>
            </form>
            <div id="errorMessages" class="alert alert-danger d-none mt-2"></div>
        </div>

        <div class="col-md-6 text-center">
            <!-- Sign Up Section -->
            <h2 class="mb-4">Sign up</h2>
            <button class="btn btn-outline-primary w-100 mb-3">Continue with Google</button>
            <button class="btn btn-outline-primary w-100 mb-3">Continue with Facebook</button>
            <a class="btn btn-outline-dark w-100" href="{{route('register')}}">Sign up with email</a>
            <p class="mt-3 small">By clicking Continue to join or sign in, you agree to Broadstage's
                <a href="#" class="text-decoration-none">User Agreement</a>,
                <a href="#" class="text-decoration-none">Privacy Policy</a>, and
                <a href="#" class="text-decoration-none">Cookie Policy</a>.
            </p>
            <p class="text-success small">Your data is 100% secure and private</p>
        </div>
    </div>

    <div class="row mt-4 w-100">
        <div class="col-12 text-center">
            <div class="alert alert-light border" role="alert">
                <strong>Looking to create a business account?</strong><br>
                Start by signing up for a general user account, which will act as the administrator for your business
                profile and manage the page effectively.
            </div>
        </div>
    </div>
</div>
@push('scripts')
    <script src="/assets/js/signin.js"></script>
@endpush
@endsection