@extends('layouts.profile_without_menu')

@section('content')
<div class="container pb-5 mb-5">
    <div class="row justify-content-center my-prfessional-category-div">
        <div class="col-lg-11 mb-4">
            <h2 class="profile-title">Select your main profession category that you identify with</h2>
        </div>
        <div class="steps-div">
            <ol class="custom-ordered-list col-lg-11 mx-auto mb-5 mt-4 t d-flex justify-content-center gap-1">
                <li class="d-flex gap-2 align-items-center step-done">
                    <img class="m-auto" width="24" src="{{ '/images/cinema.svg' }}" alt="start step">
                    <span>{{session('step2.industry', null)}}</span>
                </li>
                <li class="d-flex gap-2 align-items-center step-active">
                    <img class="m-auto" width="24" src="{{ '/images/cinema.svg' }}" alt="start step">
                    <span>Cinemas</span>
                </li>
                <li class="d-flex gap-2 align-items-center step-2">
                    <img class="m-auto" src="{{ '/images/gray-md-line.svg' }}" alt="2 step">
                </li>
                <li class="d-flex gap-2 align-items-center step-3">
                    <img class="m-auto" src="{{ '/images/gray-md-dash-line.svg' }}" alt="3 step">
                </li>

            </ol>
        </div>
        <form method="POST" action="{{ route('store-profile', ['step' => 3]) }}">
            @csrf
            <div class="grid-4 col-lg-11 mb-4">
                @if(count($profileTypes) > 0)
                    @foreach ($profileTypes as $profileType)                              
                        <div class="checkbox-card">
                            <input type="radio" name="profile_type_id" id="{{$profileType->id}}" class="checkbox" value="{{$profileType->id}}" {{ (session('step3')['profile_type_id'] ?? old('profile_type_id')) == $profileType->id ? 'checked' : '' }} required>
                            <label for="{{$profileType->id}}" class="card">
                                <img class="icon" src="/images/{{$profileType->icon_img}}" alt="models-icon" id="model-icon">
                                <img class="separator" src="{{ '/images/separator-line.svg' }}" alt="separator-line"
                                    id="separator-line">
                                <div>
                                    <div class="title">{{$profileType->name}}</div>
                                    <div class="sub-title">{{$profileType->description}}</div>
                                </div>
                            </label>
                        </div>
                    @endforeach
                @endif
            </div>
            <div class="col-lg-11 mt-5">
                <div class="d-flex justify-content-center gap-3">

                    <a type="button" class="back-rounded-btn text-decoration-none" href="/profile/step/2">
                        <img src="/images/left-arrow.svg" style=" transform: scaleX(-1); filter: brightness(0)"
                            alt="left arraow">
                        {{ __('Back') }}
                    </a>
                    <button type="submit" class="continue-btn">
                        {{ __('Continue') }}
                        <img src="/images/left-arrow.svg" alt="left arraow">
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection