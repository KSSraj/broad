@extends('layouts.profile_without_menu')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="breadcrumb d-flex justify-content-between ">
                <div class="d-flex gap-2 align-items-center">
                    <img class="icon" src="{{ '/images/actors.svg' }}" alt="actors" width="32" height="32">
                    <span>{{$profile->title}}</span>
                    <img class="icon" src="{{ '/images/gtr-icon.svg' }}" alt="actors" width="24" height="24">
                </div>
                <div class="d-flex flex-row gap-4">
                    <div class="d-flex gap-2 align-items-center">
                        <img class="icon" src="{{ '/images/check-green.svg' }}" alt="actors" width="24" height="24">
                        <span>This is your default profile</span>
                    </div>
                    <div class="d-flex gap-2 align-items-center">
                        <div class="switch d-flex">
                            <input id="profile_visibility" type="checkbox" class="toggle">
                        </div>
                        <label for="profile_visibility">Invisible Profile</label>

                    </div>
                    <div class="d-flex gap-2 align-items-center">
                        <img class="icon" src="{{ '/images/preview-mode.svg' }}" alt="actors" width="24" height="24">
                        <span>Preview Mode</span>

                    </div>
                </div>

            </div>
            <!-- profile banner -->
            <div class="profile-banner">
                <div class="bg-wrapper">
                    <div class="mask-wrapper">

                        <!-- SVG Definition -->
                        <svg xmlns="http://www.w3.org/2000/svg" style="position: absolute; width: 0; height: 0;">
                            <defs>
                                <clipPath id="customClip">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M144.99 49.8696C139.533 39.0171 133.169 28.5935 125.96 18.698L123.634 15.5369C120.771 11.6086 117.019 8.33266 112.65 5.94741C108.28 3.56213 103.404 2.12735 98.3751 1.74733L94.2923 1.43618C81.6254 0.4744 68.8982 0.4744 56.2318 1.43618L52.149 1.74733C47.1201 2.12735 42.2439 3.56213 37.8746 5.94741C33.5055 8.33266 29.753 11.6086 26.89 15.5369L24.5645 18.7262C17.3549 28.6218 10.9913 39.0454 5.53426 49.8979L3.77705 53.3913C1.61189 57.6999 0.488525 62.4105 0.488525 67.1809C0.488525 71.9514 1.61189 76.6618 3.77705 80.9706L5.53426 84.4639C10.9913 95.3167 17.3549 105.74 24.5645 115.636L26.89 118.825C29.753 122.753 33.5055 126.029 37.8746 128.415C42.2439 130.8 47.1201 132.235 52.149 132.615L56.2318 132.926C68.8982 133.887 81.6254 133.887 94.2923 132.926L98.3751 132.615C103.407 132.23 108.286 130.789 112.656 128.396C117.025 126.003 120.775 122.719 123.634 118.782L125.96 115.593C133.169 105.698 139.533 95.2743 144.99 84.4215L146.747 80.9281C148.912 76.6194 150.036 71.909 150.036 67.1385C150.036 62.368 148.912 57.6575 146.747 53.3488L144.99 49.8696Z"
                                        fill="#AC8C09" />

                                </clipPath>
                            </defs>
                        </svg>

                        <!-- Image Container -->
                        <div class="custom-shape">
                            <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUSEBIQFRUQFRAQDw8PEBAPEA8PFhUWFhUVFRUYHSggGBolHRUVITEhJSktLi4uFx8zODMtNygtLisBCgoKDg0OGBAQGy0dHR0rLS0rLS0tLSstLS0tLS0tLS0tKystLS0tLS0tLS0tKy0tLS0tKy0tLS0rNy0tKzUtK//AABEIAKMBNgMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAAIDBAYBBwj/xAA6EAACAQIEBAQEBAUDBQEAAAABAgADEQQFEiExQVFhEyJxgQYUMpEVQqGxI1JiwfAHM9FDY4KSoiT/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBAUG/8QAKREBAQACAQMDBAEFAQAAAAAAAAECEQMSITEEE0EiMlFh0QUzcYHxFP/aAAwDAQACEQMRAD8AzzZYek7+GmaLwj0jWpHpIG6zhwBjfkDND4J6Rww/aMd2c/DyY9MuM0JoHpEE7QDOVcERIlwjTTGgTyiGE7RHus98kZWbCEGas0O0r1MH2gV3QBaBllMEYWTBHpLlPDdoaVMqAfh5j/w0zQjDnpJUodo+lXXWbXLD0jvwy80zYftM/wDEecCgCq7NwJAUtf8AlQHa4uCSdluOPCGi6lPE4VKdtbAX4Dizeijc+0sYHKGq2IBRTb+JWtRWx52Yg2mSpZq5bU4+o38rElgOGpzu37dJ6B+KJUoKuKakocKE1Xape38xNwftwhe0PC9V0DYqhSoNauzebemadm10wbahx48pMMLSe3gVFYkXFN3pU6p/8S37Xgb4lwvhONPiMpAINYMG0kbAEgXXieEytevZxoG54m9re/KKWUZW49npAwBB0sCrfytbf0I2PtHfhx6TM5fTpYmi1O4puoDK1nZbjfzPx25Hl7Sz8KfEdVH8HFNrp3CLiCbtTbgA5/Mp6/4K1B7uQ7+HmIZeek0hodpzwe0NH7mX5Z78NMX4YZovC7ThXtDQ68mXrZcekp1cuM11Sn2kJw/aLRXLKsquXkTjYQzVHD9oxsJ2i0XVkzC4QzpwpmjGG7Rpw3aB9eTNHLzJBgzNB4Pad8LtFYUysZ75UxHBmaHwe0etDtFo/cy/LLtgzI0wRE1vyw6RfKjpHodeTKfKnpOzTNhR0ij0nqyFbThUROZwGM3CgjggjC0erRkRQRvhiSRQ0ZgQRwUTto5VhoGeGIvDEltGwPRLSEeEE6s7aAIKI9VE4I5YAF+LfiBMFQ1mxqPdaKfzPbif6RxPsOc8ho6qrGpVYu7XJLHZNTbC3NibkCEP9Qc+NbGHQbLhiaVM7bsD529z+gEEZVrZgtMc9zyHU3h+0ZbvaLFVjca7jf6QoLFedt+O3GGhiDTqisA+gWA8W5YLaxN+trkDhtCuSfDoJDt5jzZt7nr6TVjJVKEMoIIPrvz9ZNu23H6e+QTUuL1FVBWwAcAKf02let8KUyvO/rtL2Cy+vhLolI1qJN18JkWqnbS5AI9DKuOfG1m0jDvSpc9VSkKlT183lHpeTdxvOPGz6vIE2QtRfXQb1X8rj13mfzesRVJ0aNWxXYgHmLdO09EoYWoAFZEVVGlQrliAOHL+8zXxXgRa/a3p0hjl3Y8vF0zcegfAGZfMYKmSbtS/g1CeOpQLH3XSfeaLQJ49/pZmxpYrwWNlrqVty8Rd1PrbUPeewGpNmeN7EUEYySUNeRVGiNEyiN0idJjSYgcFE6UEjDSUmIkTUxGNTEmJjLwCsyCLwx0k5SLTAIAgkqoIis6ogDhTETII5Z0wCHwxFJgIoBSvGs1pEWkb1LwSkNSPV5AgnMRVCxja6rSQGCPnx1j1zEdRAbFbzqtBgzFes4cyXrA+qC95y0Frma9ZIMzXqIh1QSAnYL/FV6iL8VXrGXVBa8oZ9jmoYatWT6qdNmW/DVbYyH8UXrBvxJmKnCYgdaNUfdTAdUeMG7NubliST1JO5noHwflQCbjd2JJPJAbfrMFgms6k9Z6nkTAIGHA/4ZOfhpwTeQ9gF+25Hpy/S0LePvp7D+8zFLH1CdNFRYbXbhLeDzPEq1np07cNXE2+8nF29c8DBrC9pDV35S1SxAbcqvtB2b5gdNqVrtsoHG8LP216tRWrbcZnviGiGX2No+lgXN2qYje+6KC4XsSOEo4qqR5SQwOwYG9jI1py559Us0xKlqNYEEgowYG24INxPfMFihVo06q8KqJUHbUAf7zxD4lw9ir9fKfUbienfCOOIwVJHFjTUpa/5QTp/wDkiby7jj+22NTRMZXMFjMwIypmy9YH1QRBj7QOMzEeM0EQ6oLaYmMFfio6zhzQdYDqgmWjRBJzMdY4ZqOsB1QXiAgn8UWOTNATa8B1QW0xWjKVW4vOGpBR9p2RGrHK8AkijQ8UAFGcKSUiNMGaBzaCc3rHaFK5sICzGpcwTl4RikxF4vBbvL+E+mWaWkwLQP4L944Um7w74azngCB6BPAaQ1KD8rwuy+awl6lhxbeIdLMJh37yenhm7zSfLjpOrhRGOkBXCN3kWNy9mpuu/mR1+4M1K4USRcMIH0vn+kNxfqB6bz1mhQ00lA/lH7Tz74iwQp4kgcC3mFraXU6ag+4v6MJuMkxniUVPTb7SOTw6PT/dYuYQMCqKVU1SQGqGyr3Jlmk3mYCsbjVpZxTNOoVNiLA6k7E8YlpeIRfl+svGleym+3IWH7SZezr9uo6eKI024tygrNHK1ATsGuNtrX5wniKOlt/yylnS3W9pLe4bxT4tSyIEAQU1UJo46rklg3U339BA+IwrNUNRhu31GwFz1tC+R0g62uQRz5H2lrG4IqOojtvll7MZXH5VTqITUPlVk1H+QMdJbYi9r39hNHl+EQj+EfJZFBuWsQoB3tc79oHzHelUXqvD0IMt/ANR2pNazBHCsmpVYArcMtzvwIt2l4Vxc2Gsl/FYAgbb9xeAK9Jwec9Bq0BB1XL1J4CXYwuDLYbDsessNhWHWaRMGBynKmHEXcdLNfLtGmg00Jw0Xy4i7n0s74DRpomaM4YSI4SHcdICaJjApBmifDi0F4ujYwicpoUweKsgkq4q8p4Wl5RLPgWgpaU3kolfDy1plKIGKdE7AB3iRa4jTnPDjQirbwHmlPSRDzpAudDcRJy8JsCLrI6qkcJbyyjtJauH3gelTDMZdS5j6GH2lmnSgNK1GlvvL2nadWjHBYK0YtOSAWjxGMIGnpkR5WQ05YWBvLvjrKF+eHEDEp4gtcg1VBU+lwo+8j+GXamTTbgdx7TR/wCpFBh8tXQf7TujEcQGAI9vK0AU7nEKwU6HBKkcAbDaRn4Xx9spY1+CbeH6lOmACpvtfuJl8M5FoXWr5d9hzMzwunq9U0r5rVBYXIHrtePxy0Woje1lHMG5gnF/ENO5CecjYW4X9ZT0V65J006a28pY6ST+9uMpleX4nczCYpqZ8gPHfoRD1PHl1see1+V5l62Hqr/1aY9zx+0r1amJpr4iMKiDzOg426jaTpnOTLHzBLHKQx9xNN8JZOMPSLEgmuVfbcKmnyi/M7k+/aZSrjRVAYHfSNQ4EbTcZbtQpD/t0zxva6g/3l8bn5ru7XGeMvGR01YumROI8xERBARGOJPonPDiJEgjysdpigaGokEZiP3hurwgbMhtFPKcvAhgk8olh6e0gwJ8gl0cIznhUWW0FxKj7GWcO8BEmmckkUDCSZzVOgztpTMwwLng8yw4YEz36liLLwK5WNvYSxiFlbAtYe0mrPtEcOpOBJFqDrMbnOfik1rwQvxYb84RNzkenq86ZnMhzpaw2IvDqvG0mW007eRa4g0JLRamEerWlHEY1Kf+4wW/AtsD7naOqY9FtquAdw2xUjsRsY+mjqjuc0PFoVEFtRVtFxcawNh78PeebZHndOmlcVSdAqqtHbddZY2ta4A0H0vaenisDwPK46kTyz4wwlKljlcKAlXTWcEDSGBIew77G3WFwvyJnq7jXUath16AczyEps1bEuKJ1UU0k1PMNTHotuPEb+8p5Tj/ABEDC4F7Kdr7cDaHMKDsb3IN72tbYCwH+cZz+K7pl1TZy5WlMaaICf121ufc8JJTwQ0kVGbfoxBt6gXHsZcptfjLCUgZUXjZPAJicEpNwDKdenpUg8DsRyImhrJaA8xJsSYqWeQXSwyjZAAWIHr0uZtMDhmSwNR2AUKFaxta1rG3ADYCZrI8OtWoQ3BF1W6m4Fj95rqR2F5WEcmdSgx0jvHAzRm7FOXjhA3BOTpjIg6ZwidBjwIBBVG0EZoPLDVaB83+mGk5eFvB/QJbpnaVMCf4YllDFTnhFXG87h33na3CV6bbwAoGikdOKMwYNaOWpKytHFpTJK9WCM3e7rCKm8F5v9a+0ConhHlqsw0n0grDVN5ZLXiOMPiMvavigpBtcm/aTZl8OKtwL7TYYTDKG1W3keJKnUTzmNzviOjj4JrdY74YoPTxAUX0nj6zZ47OkTZSCeBP/Ey+PxgoqSv1NtfoIIwdctux3Y7ek3w7965eS9NsjXnOmPD7mRNmTEbgOvMAkMO4I4faAquLC8Jyrh/EGukSG7bX9xzmu2G6MU8yqbrTcVUPHD4o2b0Sqbg+jSCljtOoUNWncV8BV2ZLcWpjt/T9hAgxtQGz724hxv8AfjLHzVKpYVA4I+lgdRTppb6gO28NgXw2eqtlZz4TH+HVv58O/RuqH9IF+M8y8bShClqdz4o78hbYjYGNxqrbzMtS/wBNRCFq36VF/N68YJKRW7OXQx8G1rhqJ47uAfzDnb0/vNLQxJQ26Tz/AA1RlcMpIKm6kbEGbvLMamJTewqKPMBsfUdRObkw77eh6fk6pr5E6OYb3/wwiM0QD6hABwDddoxsubvI3p09xPFZ8OQgfEYxqptawjfkzedxFVKKlnIA/U+kC1as5NiDTqgDcuCpXqOO32mrw+KDbA7jiOYnkuBzh2xi1FbR9a0yeCEqwDH3M1mCzGih82M8WtzZaZCnsZ0YY9nDycn1dvDbq0eDBmAzFKg2IvzF5d8YQs0cu04MdeVPmBF8wOsRrZMjJkIricauIGsKZIDBAxnntCC1IgdXMFZr9MvV6kHZk/llTyjPwtYI+QSdTKeDfyCT06kVhzwnPCVpOXlSq8Qq/RqbRShSrRRjashE64EzAzMgy1RzQyfchdFFFBBgvNT519oQw2I1QbmZ/iL7RyoymlzDDeXCbSh4wXeUMbmXSMt6FhixqsDBGbYwi4gtcWwqAzud4xdFxxO0yuPdvhy/Rf0BZpiS7ceg/SNovYjtIDuRJBxnRJpx5XdWtWogdYdpYFtIFMkH14wLgaJJuo4ddheHqDMu9TEAW/Ith+vGXE6UsVRxHCpRLgc9Oo+xG8E1ksdw69muP33h/Mq4YaqdWzLvYVLahz58ZVoZ3VtZgKg/rW/6xXRzG3tIEAmIkc9v1kmJrgsSxQE/lUjb0AvIarheN/8A0b+4k7X7eX4NqC3A3lrJKD1K1qblGQPU1/yhFLfra3vIyotfqLyKgAbsl7338wFj1Ft4qfFJvd+G6TPaI2Z9JHHUtrn0F7R9f4koqNmVuw3nnzC978eZ7yMAdBM/ad2Xrsd/Tj2/y0mO+KOOgC5mcxmJeobuSfXl6CdsJGVlzCRz8nqs+Tt4n6NwuHLMBqReet20qPeaHLRQp8cTS6nSlRrn10wHSoFjZQSegF5OMGVPm0n+li9O/wBwJbC3ba5XjKL1FSlVLuxAVUpPcnttN1icgqpQNRiTUXc01KNpp82Y34+kxX+lqp89TvTpppDkMHDkkKbDiZusP8OvhGxmKev4i1hVqsHuWRdNSyL66xfsoEWXdvxYzW2epU6j30KzaRqbSC1l6m3ARMHU2YMD0YEH7GWsk+LU8NUqsnAB0qUwobfch127i9pFiMcr1Av1MylzVWqKtNlBCgLtcW7kyNL3DFZp1w0lW0kvENhK3FQXh8cIExX+4sMK20IKjrmDse3lhGs0oZl9MqeWeXh3BsdMmpPvIcvPlknOKieFk1ZVr1I16kawgdKm8Uau0UCY8jePQ2jVO8VUzmdGxnKqm5kOYm9VfWR5M+xkmKfzXm+M7OfO7V85xOmwgzVzjc+rXAPSR0al1HpKjG967WaCsZVJsL8N5frNA9VrkmVIR9OPp8ZEnCWMHxv9h1MotLL1vDXjbmbdekgwuXl7u9/NuBwkqUNb2P0093/qfpC2oRTu1z+j6J5+QRsPY283sxnfBXnv6kmX8RRvvKzLaNlc8vyjpoARYD7SxmlIG3e15Eg3ljF8oFFY77cOV+krrhWpMdY4EWZTcMp4EHmDOY1vLYcW2l7B5mpo+BWTddTUqu+oMeR9ftw25yb2XjNwOo3LHe1yYQNj9YB5XvuPeQUMOzMBRK1OPkXaovcqf7XA5y98hXvoVAWtcqHpnSOpOq1toWxeNzx8B9bCnih1AbkD6h7SpqmmT4eqIhr4ioKSo6o6qddbzX+kKCt9t99ri8G1qdKqTpup3IJtcjvaTMnRjwTl7Y/Tl+Pz/j+Ay8npZhVXYO1v5SdQ+xkeIwjpx3HVZXDS5dubPjywuspqtb8G5+lHF0alVUChwHdFCEKdiTbYje/tPVPjTG//AJtJOpHJc1gyqjC38NFs13JJB2FrA+k8WyLBI7E1dRVbHSp06j0vyHGa7K8rovtSplCou41s67na2okiTll8O3i9Pyez7nwoHCMaRq6qYGrQFIYFm06gBpFh0ljKwtMhtaF9wyo51UzzVhaxU7WNxBGYV6gZ0DnQHYBQBbykreEMkyxa53rqlQgmzIFTbbcg7bAcjImU20z9ByzHqkaFMZfhJPmjM7Ww9eh5iPKeFRTqQ+//ADDmAqiogYceDDoZd/Tj1ljdZTVMrVbusLrUgfErZhCAqgSYvJJVaVMxPlkjVxfjIMwrArHGd8GZdU5QhaCcC4hL5hesKJ4dajvJNG0aMQvWd+YWClWrsYo3E1heKCWRUxFpBR1GSikZhpr1SiWXuAsr5nXsNo4UfJfpKGJUkTWVjnAbMcQTt1ljCGw3jamFub9JM2HKrqPD9zLZK+PqbW6wbV4Sau9zIH4gSinlLyk9EEIWHHgPU7SB5OTZUXrdz6DYf3hW3DNW5X4n/F7DWUBRy59TzMuIZRw28uWjc5VW2lJjJ6zSuYB1OMdiW39IxY1zAOUkBYFvyi49Y2vT81/tJcPbe/tGVTcwChoIe63BvcEQxTxNa1jWq7b/AO42x+8GhrNvwlguW2XhFqKuVR1qmokAk8ySb3PU94x6RFiDYjgZcXDhRcyrVqfaGhLZdxfwmIDixsGHEcm7iRYjAKTddj/n3guk51ahtbhC2DxoqCx2YcR/N3EysuPePd4Obj9Vj7fN93xRX4eVEDM+7bKqKCxJ6zQZJmSYY1BVpVR4ug0z5TZATe63vxmYwuJKMCtgQCNVtxf/AD9TLV9RudyeJMi5d9vT4/Ry8Htb7RRr1LksSvmdxa92uLEkgcBvt1sZZwOKKI+lTqqAKGOwRb3NhzMkego5C8r1BfhIt26ceGyayu4nwmcVqY0hgV4aXGpSOh7S1lWP01SOC1ACF5AkXAH7QZ4UjxlUB6ZXkqqfUEj/AImnHXm/1fik4pl+K1r1bsJDnNcqARGUagKow/NY+/OQ5691EuPBz8O4cswvczuKVgJPlP0yfHjyxo12DsOjEbXkxpv3lzL18snqCAkDVV+sdpfqZfCx4ED0EvTeKFrCKMtMzTUWk6CKKZNImqfSYPttFFCCqZE7nxtQp25k377RRTVlj4rOGMH1CcilM4mqSSofP6KtvtORQvlrh/by/wBL+CMvGdijc6rVkZEUUA5IjFFAJcOPLf1/eQmKKAUjvUsesO0EAGwiiguq+OMHVeEUUEmW2lVGINwbEc4ooq1473aqmbql+Y1Huesu01EUU5a+24PtaT4YyqjVDGqmqxAF2YCxHQGCvivCJSxL06S6VXRZQSbXUE8fWKKHw5uPK/8Aqym+2v4BiYLxZ8w/zmYopeHlj/Wf7H+2lypv4Q7M1pzNz5RFFNHzl+1eyb6JZx/0zkUE/DuX/TJ6hiijOEs6YooAlMUUUDf/2Q=="
                                alt="Masked Image">
                        </div>

                    </div>


                    <img src="/images/profile-banner-bg.png" class="img-fluid banner-ng" alt="">

                    <div class="profile-details-wrap">

                        <div class="user-fullname d-flex align-items-center gap-2">
                            Aishwarya Rai Bachchan <img src="/images/fluent_shield.svg" height="24" alt="">
                            <span class="yellow-text">(She/Her)</span>
                        </div>
                        <div class="spit-2">
                            <div class="left">
                                <div class="user-profesion">
                                    <ul class="m-0 d-flex">
                                        <li>Voice over Artist | Voice Actor</li>
                                    </ul>
                                </div>
                                <div class="user-address">
                                    Mumbai, Maharashtra, India
                                </div>
                            </div>
                            <div class="right">
                                <div class="caption yellow-text">working at</div>
                                <div class="d-flex gap-2 p-2 px-0">
                                    <img src="/images/left-border-line.svg" alt="">
                                    <div>
                                        <div class="company-name">Yashraj Talent Hunt</div>
                                        <div class="company-type">Casting Agency</div>
                                    </div>
                                    <div class="ms-3">
                                        <img src="/images/company-img.svg" height="48" alt="company img">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="user-badges">
                            @php
                                $badges =
                                    [
                                        ['title' => '10 years Experience', 'img' => '/images/card-with-ribon.svg'],
                                        ['title' => 'Awardee', 'img' => '/images/award.svg'],
                                        ['title' => '1000 - 2000 / Day', 'img' => '/images/heroicons_currency-rupee.svg'],

                                    ];
                            @endphp
                            @foreach($badges as $badge)
                                <x-badge :content="$badge['title']" :image="$badge['img']"></x-badge>
                            @endforeach
                        </div>
                    </div>
                    <div class="user-status">
                        <img src="/images/ph_info.svg" height="16" width="16" alt=""> <span
                            class="yellow-text">Active</span>
                    </div>
                </div>
                <div class="inner-navbar my-3 px-3">
                    <ul class="nav nav-tabs" id="tabs-nav" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="details-tab" data-bs-toggle="tab"
                                data-bs-target="#details" type="button" role="tab" aria-controls="details"
                                aria-selected="true">
                                Details
                            </button>
                        </li>
                        <li class="nav-item" role="presentation"><button class="nav-link" id="media-tab"
                                data-bs-toggle="tab" data-bs-target="#media" type="button" role="tab"
                                aria-controls="media" aria-selected="false">
                                Media
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="highlights-tab" data-bs-toggle="tab"
                                data-bs-target="#highlights" type="button" role="tab" aria-controls="highlights"
                                aria-selected="false">
                                Highlights
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact"
                                type="button" role="tab" aria-controls="contact" aria-selected="false">
                                Contact
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="feedback-tab" data-bs-toggle="tab" data-bs-target="#feedback"
                                type="button" role="tab" aria-controls="feedback" aria-selected="false">
                                Feedback & Reviews
                            </button>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- <div class="row my-4 profile-details-wrapper tab-pane fade show active" id="details" role="tabpanel"
                aria-labelledby="details-tab">
                <div class="col-lg-3 pe-lg-1">
                    <div class="d-flex flex-column gap-3">
                        <?php $empty_card = ($profile->attributes->count() > 0) ? '' : 'empty-card';?>
                        <div class="card p-2 {{$empty_card}} prof-sidebar-tabs">
                            <profile-attributes-card :profile-id="{{$profile->id}}"></attributes-card>
                        </div>
                        <?php $empty_card = ($profile->languages->count() > 0) ? '' : 'empty-card';?>
                        <div class="card p-2 {{$empty_card}} prof-sidebar-tabs">
                            <profile-languages-card :profile-id="{{$profile->id}}"></profile-languages-card>
                        </div>
                        <div class="card p-2 empty-card prof-sidebar-tabs">
                            <policy-card :profile-id="{{$profile->id}}"></policy-card>
                        </div>
                        <?php $empty_card = ($profile->description != "") ? '' : 'empty-card';?>
                        <div class="card p-2 {{$empty_card}} prof-sidebar-tabs">
                            <document-card :profile-id="{{$profile->id}}"></document-card>
                        </div>

                        <?php $empty_card = ($profile->socialLinks != "") ? '' : 'empty-card';?>
                        <div class="card p-2 {{$empty_card}} prof-sidebar-tabs">
                            <social-links-card :profile-id="{{$profile->id}}"></social-links-card>
                        </div>
                    </div>

                </div>
                <div class="col-lg-9">
                    <div class="d-flex flex-column gap-3">
                        <?php $empty_card = ($profile->description != "") ? '' : 'empty-card';?>
                        <div class="card p-2 {{$empty_card}} prof-sidebar-tabs">
                            <about-me-card :profile-id="{{$profile->id}}"></about-me-card>
                        </div>
                        <?php $empty_card = ($profile->skills != "") ? '' : 'empty-card';?>
                        <div class="card p-2 {{$empty_card}} prof-sidebar-tabs">
                            <profile-skill-card :profile-id="{{$profile->id}}"></profile-skill-card>
                        </div>
                        <?php $empty_card = ($profile->honorsAwards->count() > 0) ? '' : 'empty-card';?>
                        <div class="card p-2 {{$empty_card}} prof-sidebar-tabs">
                            <profile-awards-card :profile-id="{{$profile->id}}"></profile-awards-card>
                        </div>
                        <?php $empty_card = ($profile->experiences->count() > 0) ? '' : 'empty-card';?>
                        <div class="card p-2 {{$empty_card}} prof-sidebar-tabs">
                            <profile-experience-card :profile-id="{{$profile->id}}"></profile-experience-card>
                        </div>
                        <div class="card p-2 empty-card prof-sidebar-tabs">
                            <profile-education-card :profile-id="{{$profile->id}}"></profile-education-card>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- highlights -->

            <!-- Tabs Content -->
            <div class="tab-content" id="profileTabsContent">
                <!-- Details Tab -->
                <div class="tab-pane fade show active" id="details" role="tabpanel" aria-labelledby="details-tab">
                    <div class="row my-4 profile-details-wrapper">
                        <div class="col-lg-3 pe-lg-1">
                            <div class="d-flex flex-column gap-3">
                                @php $empty_card = ($profile->attributes->count() > 0) ? '' : 'empty-card'; @endphp
                                <div class="card p-2 {{ $empty_card }} prof-sidebar-tabs">
                                    <profile-attributes-card :profile-id="{{ $profile->id }}"></profile-attributes-card>
                                </div>
                                @php $empty_card = ($profile->languages->count() > 0) ? '' : 'empty-card'; @endphp
                                <div class="card p-2 {{ $empty_card }} prof-sidebar-tabs">
                                    <profile-languages-card :profile-id="{{ $profile->id }}"></profile-languages-card>
                                </div>
                                <div class="card p-2 empty-card prof-sidebar-tabs">
                                    <policy-card :profile-id="{{ $profile->id }}"></policy-card>
                                </div>
                                @php $empty_card = ($profile->description != "") ? '' : 'empty-card'; @endphp
                                <div class="card p-2 {{ $empty_card }} prof-sidebar-tabs">
                                    <document-card :profile-id="{{ $profile->id }}"></document-card>
                                </div>
                                @php $empty_card = ($profile->socialLinks != "") ? '' : 'empty-card'; @endphp
                                <div class="card p-2 {{ $empty_card }} prof-sidebar-tabs">
                                    <social-links-card :profile-id="{{ $profile->id }}"></social-links-card>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="d-flex flex-column gap-3">
                                @php $empty_card = ($profile->description != "") ? '' : 'empty-card'; @endphp
                                <div class="card p-2 {{ $empty_card }} prof-sidebar-tabs">
                                    <about-me-card :profile-id="{{ $profile->id }}"></about-me-card>
                                </div>
                                @php $empty_card = ($profile->skills != "") ? '' : 'empty-card'; @endphp
                                <div class="card p-2 {{ $empty_card }} prof-sidebar-tabs">
                                    <profile-skill-card :profile-id="{{ $profile->id }}"></profile-skill-card>
                                </div>
                                @php $empty_card = ($profile->honorsAwards->count() > 0) ? '' : 'empty-card'; @endphp
                                <div class="card p-2 {{ $empty_card }} prof-sidebar-tabs">
                                    <profile-awards-card :profile-id="{{ $profile->id }}"></profile-awards-card>
                                </div>
                                @php $empty_card = ($profile->experiences->count() > 0) ? '' : 'empty-card'; @endphp
                                <div class="card p-2 {{ $empty_card }} prof-sidebar-tabs">
                                    <profile-experience-card :profile-id="{{ $profile->id }}"></profile-experience-card>
                                </div>
                                <div class="card p-2 empty-card prof-sidebar-tabs">
                                    <profile-education-card :profile-id="{{ $profile->id }}"></profile-education-card>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Media Tab -->
                <div class="tab-pane fade" id="media" role="tabpanel" aria-labelledby="media-tab">
                    <p>Media content goes here...</p>
                </div>

                <!-- Highlights Tab -->
                <div class="tab-pane fade" id="highlights" role="tabpanel" aria-labelledby="highlights-tab">
                    <div class="row my-4 profile-details-wrapper">
                        <div class="col-lg-12 pe-lg-1">
                            <div class="d-flex flex-column gap-3">
                                @php $empty_card = ($profile->attributes->count() > 0) ? '' : 'empty-card'; @endphp
                                <div class="card p-2 {{ $empty_card }} prof-sidebar-tabs">
                                    <profile-highlights-card :profile-id="{{ $profile->id }}"></profile-education-card>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- Contact Tab -->
                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                    <p>Contact content goes here...</p>
                </div>

                <!-- Feedback & Reviews Tab -->
                <div class="tab-pane fade" id="feedback" role="tabpanel" aria-labelledby="feedback-tab">
                    <profile-feedbacks-card :profile-id="{{ $profile->id }}"></profile-feedbacks-card>
                </div>
            </div>
        </div>
    </div>
    @endsection