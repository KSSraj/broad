<span class="badge rounded-pill">        
    <img src="{{ $image }}" alt="Badge Image" class="badge-image" height="24" width="24">
    {{ $content }}
</span>