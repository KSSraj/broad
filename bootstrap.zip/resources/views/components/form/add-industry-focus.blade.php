{{-- a form for physical information of persion --}}
 <form action="">
    <div class="form-group">

        <label for="name">Name:</label>
        <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" >
    </div>
    <div class="form-group">
        <label for="age">Age:</label>
        <input type="number" class="form-control" id="age" placeholder="Enter age" name="age" >
        </div>
         
    </form>