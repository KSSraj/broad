<form method="{{$method}}" action="{{ $action }}" enctype="multipart/form-data" name="profileExperience">
    @if($method === 'PUT')
        @method('PUT')
    @endif
   
    <div class="form-group">
        <label for="experience_type" class="form-label">Experience Type</label>
        <input class="form-control" type="text" name="experience_type" 
            value="{{ old('experience_type', $experience->experience_type ?? '') }}" required>
    </div>
    <div class="form-group">
        <label for="experience_title" class="form-label">Experience Title</label>
        <input class="form-control" type="text" name="experience_title" 
            value="{{ old('experience_title', $experience->experience_title ?? '') }}" required>
    </div>
    <div class="form-group">
        <label for="details" class="form-label">Details</label>
        <textarea class="form-control" name="details" 
            value="{{ old('details', $experience->details ?? '') }}"></textarea>
    </div>
    <div class="form-group">
        <label for="link" class="form-label">Link</label>
        <input class="form-control" name="link"  value="{{ old('link', $experience->link ?? '') }}" required>
    </div>
    <div class="form-group">
        <label for="month" class="form-label">Month</label>
        <input class="form-control" type="text" name="month"
            value="{{ old('month', $experience->month ?? '') }}" required>
    </div>
    <div class="form-group">
        <label for="year" class="form-label">Year</label>
        <input class="form-control" type="number" name="year" 
            value="{{ old('year', $experience->year ?? '') }}" required>
        <input type="hidden" name="experience_id" value="{{ old('year', $experience->id ?? '') }}">
    </div>    
    <x-primary-button>{{$buttonText}}</x-primary-button>

</form>