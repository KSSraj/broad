@if($experiences->isEmpty())
    <p>No experiences available.</p>
@else
    @foreach($experiences as $experience)
        <div class="col">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex">
                        <h5 class="card-title p-0">{{$experience->experience_title}} <span
                                class="fw-normal">({{$experience->month}}-{{$experience->year}})</span>
                        </h5>
                        <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                            data-bs-toggle="modal" data-bs-target="#editExperience{{$experience->id}}">
                            <img class="add-icon" src="/images/edit-circle.svg" height="18" width="18" alt="">
                        </a>
                       <form method="POST" action="{{route("experiences.destroy",$experience->id)}}">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm">X</button>
                       </form>

                    </div>
                    <p class="card-text">{{$experience->details}}</p>
                    <a href="{{$experience->link}}" class="">{{$experience->link}}</a>
                </div>
            </div>
            {{--<x-modal-component id="editExperience{{$experience->id}}" title="Profile Experience">
                <x-slot:title>Edit Experience</x-slot:title>
                <x-form.experience-form :action="route('experiences.update')" method="PUT" :experience="$experience"
                    buttonText="Update Experience" />
            </x-modal-component>--}}
        </div>
    @endforeach
@endif