<?php


use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProfileEducationController;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\ProfileAttributeController;
use App\Http\Controllers\ExperienceController;
use App\Http\Controllers\ProfileSkillController;
use App\Http\Controllers\ProfilePolicyController;
use App\Http\Controllers\ProfileDocumentController;
use App\Http\Controllers\SocialLinkController;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\AwardController;
use App\Http\Controllers\ProfileHighlightController;
use App\Http\Controllers\ProfileFeedbackController;


Route::get('/signup', function () {
    return view('auth.signup');
})->middleware('guest')->name('register');

Route::get('/', function(){
    return view("auth.signin");
})->middleware('guest')->name('login');

Route::get('/login', function(){
    return view("auth.signin");
})->middleware('guest')->name('login');

Route::get('/register', function(){
    return view("auth.register");
})->middleware('guest');

Route::post('/login', [AuthController::class, 'login'])->name('login');
Route::post('/send-otp', [AuthController::class, 'sendOtp']);
Route::post('/verify-otp', [AuthController::class, 'verifyOtp']);
Route::post('/register', [AuthController::class, 'register']);
Route::post('/resend-otp', [AuthController::class, 'resendOtp'])->middleware('throttle:5,1');

Route::post('/forgot-password', [AuthController::class, 'forgotPassword'])->name('forgot-password');
Route::post('/reset-password', [AuthController::class, 'resetPassword']);

Route::middleware(['auth'])->group(function () {
   
    Route::get('/profile/step/{id}', [ProfileController::class, 'showStep'])->name("show-step");       
    Route::post('/profile/step/{step}', [ProfileController::class, 'storeProfile'])->name("store-profile");

    Route::get('/profile/{id}', [ProfileController::class,'viewProfile'])->name('view-profile');  
    Route::get('/profile/aboutme/{id}', [ProfileController::class,'getAboutMe'])->name('get-about-me');  
    Route::put('/profile/update', [ProfileController::class, 'update']);  
    Route::post('/create-profile-sample', [ProfileController::class, 'createProfileSample']);
});

Route::middleware('auth:web')->group(function () {
    Route::get('/profiles/{profileId}/attributes', [ProfileAttributeController::class, 'index']);
    Route::post('/attributes', [ProfileAttributeController::class, 'store']);
    //Route::put('/attributes/{id}', [ProfileAttributeController::class, 'update']);
    Route::delete('/attributes/{id}', [ProfileAttributeController::class, 'destroy']);
});

Route::middleware('auth:web')->group(function () { 
    Route::get('profile/experiences/{profile_id}', [ExperienceController::class, 'experiences'])->name("profile.experiences");  
    Route::post('/profile/experience', [ExperienceController::class, 'store'])->name("profiles.experiences.store");   
    Route::put('/profile/experience/{experience}', [ExperienceController::class, 'update'])->name("experiences.update");      
    Route::delete('/profile/experience/{ex_id}', [ExperienceController::class, 'destroy'])->name("experiences.destroy");      
});

Route::middleware('auth:web')->group(function () { 
    Route::get('/award/{profile_id}', [AwardController::class, 'awards'])->name("profile.awards");  
    Route::post('/award', [AwardController::class, 'store'])->name("profiles.award.store");   
    Route::put('/award/{award}', [AwardController::class, 'update'])->name("award.update");      
    Route::delete('/award/{edu_id}', [AwardController::class, 'destroy'])->name("award.destroy");      
});

Route::middleware('auth:web')->group(function () { 
    Route::get('/profiles/{profile}/skills', [ProfileSkillController::class, 'index']);
    Route::post('/skills', [ProfileSkillController::class, 'store']);
    Route::delete('/skills/{skill}', [ProfileSkillController::class, 'destroy']);
});

Route::middleware('auth:web')->group(function () { 
    Route::get('/policies/{profile}/policies', [ProfilePolicyController::class, 'index']);
    Route::post('/policies', [ProfilePolicyController::class, 'store']);
    Route::delete('/policies/{policy}', [ProfilePolicyController::class, 'destroy']);
});

Route::middleware('auth:web')->group(function () { 
    Route::get('/documents/{profile}', [ProfileDocumentController::class, 'index']);
    Route::post('/documents', [ProfileDocumentController::class, 'store']);
    Route::delete('/documents/{document}', [ProfileDocumentController::class, 'destroy']);

    Route::resource('social-links', SocialLinkController::class);
});

Route::middleware('auth:web')->group(function () { 
    Route::get('/languages', [LanguageController::class, 'getLanguages']);
    Route::get('/languages/{profile}', [LanguageController::class, 'show']);
    Route::post('/languages', [LanguageController::class, 'store']);
    Route::delete('/langueges/{language}', [LanguageController::class, 'destroy']);   
});

Route::middleware('auth:web')->group(function () { 
    Route::get('/education/{profile_id}', [ProfileEducationController::class, 'educations'])->name("profile.educations");  
    Route::post('/education', [ProfileEducationController::class, 'store'])->name("profiles.education.store");   
    Route::put('/education/{education}', [ProfileEducationController::class, 'update'])->name("education.update");      
    Route::delete('/education/{edu_id}', [ProfileEducationController::class, 'destroy'])->name("education.destroy");      
});
Route::middleware('auth:web')->group(function () { 
    Route::get('/highlight/{profile_id}', [ProfileHighlightController::class, 'highlights'])->name("profile.highlights");  
    Route::post('/highlight', [ProfileHighlightController::class, 'store'])->name("profiles.highlight.store");   
    Route::put('/highlight/{highlight}', [ProfileHighlightController::class, 'update'])->name("highlight.update");      
    Route::delete('/highlight/{edu_id}', [ProfileHighlightController::class, 'destroy'])->name("highlight.destroy");      
});

Route::middleware('auth:web')->group(function () { 
    Route::get('/feedback/{profile_id}', [ProfileFeedbackController::class, 'feedbacks'])->name("profile.feedbacks");  
    Route::post('/feedback', [ProfileFeedbackController::class, 'store'])->name("profiles.feedback.store");   
    Route::put('/feedback/{feedback}', [ProfileFeedbackController::class, 'update'])->name("feedback.update");      
    Route::delete('/feedback/{edu_id}', [ProfileFeedbackController::class, 'destroy'])->name("feedback.destroy");      
});
require __DIR__.'/auth.php';
