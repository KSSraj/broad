<?php
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProfileController;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);
Route::post('/verify-otp', [AuthController::class, 'verifyOtp']);
Route::post('/resend-otp', [AuthController::class, 'resendOtp'])->middleware('throttle:5,1');

Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
Route::post('/reset-password', [AuthController::class, 'resetPassword']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/set-password', [AuthController::class, 'setPassword']);  
    Route::post('/setup-profile', [ProfileController::class, 'setupProfile']); // Step 4     
    Route::post('/create-profile-sample', [ProfileController::class, 'createProfileSample']);
});
