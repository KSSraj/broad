<?php $__env->startSection('content'); ?>
<div class="container pb-5 mb-5">
    <div class="row justify-content-center my-prfessional-category-div">
        <div class="col-lg-11 mb-4">
            <h2 class="profile-title">Select your main profession category that you identify with</h2>
        </div>
        <div class="steps-div">
            <ol class="custom-ordered-list col-lg-11 mx-auto mb-5 mt-4 t d-flex justify-content-center gap-1">
                <li class="d-flex gap-2 align-items-center step-done">
                    <img class="m-auto" width="24" src="<?php echo e('/images/cinema.svg'); ?>" alt="start step">
                    <span><?php echo e(session('step2.industry', null)); ?></span>
                </li>
                <li class="d-flex gap-2 align-items-center step-active">
                    <img class="m-auto" width="24" src="<?php echo e('/images/cinema.svg'); ?>" alt="start step">
                    <span>Cinemas</span>
                </li>
                <li class="d-flex gap-2 align-items-center step-2">
                    <img class="m-auto" src="<?php echo e('/images/gray-md-line.svg'); ?>" alt="2 step">
                </li>
                <li class="d-flex gap-2 align-items-center step-3">
                    <img class="m-auto" src="<?php echo e('/images/gray-md-dash-line.svg'); ?>" alt="3 step">
                </li>

            </ol>
        </div>
        <form method="POST" action="<?php echo e(route('store-profile', ['step' => 3])); ?>">
            <?php echo csrf_field(); ?>
            <div class="grid-4 col-lg-11 mb-4">
                <?php if(count($profileTypes) > 0): ?>
                    <?php $__currentLoopData = $profileTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profileType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                              
                        <div class="checkbox-card">
                            <input type="radio" name="profile_type_id" id="<?php echo e($profileType->id); ?>" class="checkbox" value="<?php echo e($profileType->id); ?>" <?php echo e((session('step3')['profile_type_id'] ?? old('profile_type_id')) == $profileType->id ? 'checked' : ''); ?> required>
                            <label for="<?php echo e($profileType->id); ?>" class="card">
                                <img class="icon" src="/images/<?php echo e($profileType->icon_img); ?>" alt="models-icon" id="model-icon">
                                <img class="separator" src="<?php echo e('/images/separator-line.svg'); ?>" alt="separator-line"
                                    id="separator-line">
                                <div>
                                    <div class="title"><?php echo e($profileType->name); ?></div>
                                    <div class="sub-title"><?php echo e($profileType->description); ?></div>
                                </div>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="col-lg-11 mt-5">
                <div class="d-flex justify-content-center gap-3">

                    <a type="button" class="back-rounded-btn text-decoration-none" href="/profile/step/2">
                        <img src="/images/left-arrow.svg" style=" transform: scaleX(-1); filter: brightness(0)"
                            alt="left arraow">
                        <?php echo e(__('Back')); ?>

                    </a>
                    <button type="submit" class="continue-btn">
                        <?php echo e(__('Continue')); ?>

                        <img src="/images/left-arrow.svg" alt="left arraow">
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile_without_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\broad_front\resources\views/profile/my-profession-category.blade.php ENDPATH**/ ?>