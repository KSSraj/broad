<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="icon" type="image/x-icon" href="/images/broad_stage_favicon.png">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/jquery-3.7.1.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/assets/css/sweetalert2.min.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>

<body>
    <div id="app">
        <?php if (isset($component)) { $__componentOriginalc759bbe7f27135e413cfaa65009d4435 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc759bbe7f27135e413cfaa65009d4435 = $attributes; } ?>
<?php $component = App\View\Components\NavbarWithoutMenuComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar-without-menu-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\NavbarWithoutMenuComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc759bbe7f27135e413cfaa65009d4435)): ?>
<?php $attributes = $__attributesOriginalc759bbe7f27135e413cfaa65009d4435; ?>
<?php unset($__attributesOriginalc759bbe7f27135e413cfaa65009d4435); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc759bbe7f27135e413cfaa65009d4435)): ?>
<?php $component = $__componentOriginalc759bbe7f27135e413cfaa65009d4435; ?>
<?php unset($__componentOriginalc759bbe7f27135e413cfaa65009d4435); ?>
<?php endif; ?>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

    </div>
    <script src="/assets/js/sweetalert2.all.min.js"></script> 
    <?php echo $__env->yieldPushContent('scripts'); ?> <!-- Load view-specific scripts here -->
</body>

</html><?php /**PATH D:\xampp\htdocs\broad_front\resources\views/layouts/profile_without_menu.blade.php ENDPATH**/ ?>