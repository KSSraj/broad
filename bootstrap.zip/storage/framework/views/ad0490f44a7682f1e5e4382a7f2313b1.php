<?php if($experiences->isEmpty()): ?>
    <p>No experiences available.</p>
<?php else: ?>
    <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex">
                        <h5 class="card-title p-0"><?php echo e($experience->experience_title); ?> <span
                                class="fw-normal">(<?php echo e($experience->month); ?>-<?php echo e($experience->year); ?>)</span>
                        </h5>
                        <a href="javascript:;" class="addnew d-flex flex-row gap-2 align-items-center text-decoration-none"
                            data-bs-toggle="modal" data-bs-target="#editExperience<?php echo e($experience->id); ?>">
                            <img class="add-icon" src="/images/edit-circle.svg" height="18" width="18" alt="">
                        </a>
                       <form method="POST" action="<?php echo e(route("experiences.destroy",$experience->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">X</button>
                       </form>

                    </div>
                    <p class="card-text"><?php echo e($experience->details); ?></p>
                    <a href="<?php echo e($experience->link); ?>" class=""><?php echo e($experience->link); ?></a>
                </div>
            </div>
            
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\broad_front\resources\views/components/experiences/experience-list.blade.php ENDPATH**/ ?>