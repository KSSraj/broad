
<form id="add-attributes-form">      
    <div class="form-group">
        <label for="height">Height:</label>
        <input type="number" class="form-control" id="height" placeholder="e.g. 5.5" name="height" step="0.1" value="<?php echo e($profileAttributes["Height"]??""); ?>">
    </div>
    <div class="form-group">
        <label for="weight">Weight:</label>
        <input type="number" class="form-control" id="weight" placeholder="E.g 55" name="weight" step="0.1" value="<?php echo e($profileAttributes["Weight"]??""); ?>">
    </div>
    <div class="form-group">
        <label for="build">Build:</label>
        <input type="text" class="form-control" id="build" placeholder="E.g Average" name="build" value="<?php echo e($profileAttributes["Build"]??""); ?>">
    </div>
    <div class="form-group">
        <label for="hair">Hair:</label>
        <input type="text" class="form-control" id="hair" placeholder="E.g Black" name="hair" value="<?php echo e($profileAttributes["Hair"]??""); ?>">
    </div>
    <div class="form-group">
        <label for="eyes">Eyes:</label>
        <input type="text" class="form-control" id="eyes" placeholder="E.g Eyes" name="eyes" value="<?php echo e($profileAttributes["Eyes"]??""); ?>">
    </div>
    <div class="form-group">
        <label for="skin">Skin:</label>
        <input type="text" class="form-control" id="skin" placeholder="E.g Black" name="skin" value="<?php echo e($profileAttributes["Skin"]??""); ?>">
        <input type="hidden" class="form-control" id="profile_id"  value="<?php echo e(session('profileId')); ?>">
    </div>
    <div class="form-group my-2">
        <button type="submit" class="btn btn-primary">Save changes</button>
    </div>
</form>

<?php $__env->startPush('scripts'); ?>
    <script src="/assets/js/manage-attributes.js"></script>
<?php $__env->stopPush(); ?><?php /**PATH D:\xampp\htdocs\broad_front\resources\views/components/form/add-attributes.blade.php ENDPATH**/ ?>