<form method="<?php echo e($method); ?>" action="<?php echo e($action); ?>" enctype="multipart/form-data" name="profileExperience">
    <?php if($method === 'PUT'): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
   
    <div class="form-group">
        <label for="experience_type" class="form-label">Experience Type</label>
        <input class="form-control" type="text" name="experience_type" 
            value="<?php echo e(old('experience_type', $experience->experience_type ?? '')); ?>" required>
    </div>
    <div class="form-group">
        <label for="experience_title" class="form-label">Experience Title</label>
        <input class="form-control" type="text" name="experience_title" 
            value="<?php echo e(old('experience_title', $experience->experience_title ?? '')); ?>" required>
    </div>
    <div class="form-group">
        <label for="details" class="form-label">Details</label>
        <textarea class="form-control" name="details" 
            value="<?php echo e(old('details', $experience->details ?? '')); ?>"></textarea>
    </div>
    <div class="form-group">
        <label for="link" class="form-label">Link</label>
        <input class="form-control" name="link"  value="<?php echo e(old('link', $experience->link ?? '')); ?>" required>
    </div>
    <div class="form-group">
        <label for="month" class="form-label">Month</label>
        <input class="form-control" type="text" name="month"
            value="<?php echo e(old('month', $experience->month ?? '')); ?>" required>
    </div>
    <div class="form-group">
        <label for="year" class="form-label">Year</label>
        <input class="form-control" type="number" name="year" 
            value="<?php echo e(old('year', $experience->year ?? '')); ?>" required>
        <input type="hidden" name="experience_id" value="<?php echo e(old('year', $experience->id ?? '')); ?>">
    </div>    
    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($buttonText); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>

</form><?php /**PATH D:\xampp\htdocs\broad_front\resources\views/components/form/experience-form.blade.php ENDPATH**/ ?>