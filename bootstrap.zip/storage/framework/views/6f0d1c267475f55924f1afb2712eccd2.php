<form id="profileExperience">
    <div class="form-group">
        <label for="experience_type" class="form-label">Experience Type</label>
        <input class="form-control" type="text" name="experience_type" id="experience_type" required>
    </div>
    <div class="form-group">
        <label for="experience_title" class="form-label">Experience Title</label>
        <input class="form-control" type="text" name="experience_title" id="experience_title" required>
    </div>
    <div class="form-group">
        <label for="details" class="form-label">Details</label>
        <textarea class="form-control" name="details" id="details"></textarea>
    </div>
    <div class="form-group">
        <label for="link" class="form-label">Link</label>
        <input class="form-control" name="link" id="link" required>
    </div>
    <div class="form-group">
        <label for="month" class="form-label">Month</label>
        <input class="form-control" type="text" name="month" id="month" required>
    </div>
    <div class="form-group">
        <label for="year" class="form-label">Year</label>
        <input class="form-control" type="number" name="year" id="year" required>
    </div>
    <button type="submit" class="btn btn-success my-2">Submit</button>
</form><?php /**PATH D:\xampp\htdocs\broad_front\resources\views/components/form/add-experience.blade.php ENDPATH**/ ?>