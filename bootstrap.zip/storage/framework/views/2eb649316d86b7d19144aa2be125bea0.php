<?php $__env->startSection('content'); ?>
<div class="container pb-5 mb-5">
    <div class="row justify-content-center my-prfessional-category-div">
        <div class="col-lg-12 mb-4">
            <h2 class="profile-title">Tell us more about your job</h2>
        </div>
        <form action="<?php echo e(route('store-profile', ['step' => 5])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="grid-4 single-card-grid col-lg-12 mb-4 text-center gap-4 m-auto">
                <div class="checkbox-card">
                    <!-- <input type="checkbox" name="profession_category[]" id="production-crew" class="checkbox"> -->
                    <label for="production-crew" class="card">
                        <img class="icon" src="<?php echo e('/images/production-crew.svg'); ?>" alt="production-crew-icon"
                            id="production-crew-icon">
                        <img class="separator" src="<?php echo e('/images/separator-line.svg'); ?>" alt="separator-line"
                            id="separator-line">
                        <div>
                            <div class="title">Production Crew</div>
                            <div class="sub-title">Sound, Camera etc.</div>
                        </div>
                    </label>
                </div>
                <div class="d-flex  flex-column gap-3" style="max-width:400px; width:100%;">
                    <div class="group">
                        <h2 class="profile-title">Select your department</h2>
                        <?php if(!empty($departments)): ?>
                            <select class="form-select form-control form-select-md mb-3" name="department" id="department"
                                aria-label=".form-select-md example" >
                                <option>Open this select menu</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                      
                                    <option value="<?php echo e($department->id); ?>" <?php echo e(old('department') == $department->id ? 'selected' : ''); ?>><?php echo e($department->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                    </div>
                    <div class="group">
                        <h2 class="profile-title">Select your Job Title</h2>
                        <input type="text" name="title" id="job_title" class="form-control"
                            placeholder="E.g. Makeup Artist">
                    </div>
                </div>
            </div>
            <div class="col-lg-12 mt-5">
                <div class="d-flex justify-content-center gap-3">
                    <a type="button" class="back-rounded-btn text-decoration-none" href="/profile/step/4">
                        <img src="/images/left-arrow.svg" style=" transform: scaleX(-1); filter: brightness(0)"
                            alt="left arraow">
                        <?php echo e(__('Back')); ?>

                    </a>
                    <button type="submit" class="continue-btn">
                        <?php echo e(__('Continue')); ?>

                        <img src="/images/left-arrow.svg" alt="left arraow">
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile_without_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\broad_front\resources\views/profile/my-profession-details.blade.php ENDPATH**/ ?>