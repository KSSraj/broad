<span class="badge rounded-pill">        
    <img src="<?php echo e($image); ?>" alt="Badge Image" class="badge-image" height="24" width="24">
    <?php echo e($content); ?>

</span><?php /**PATH D:\xampp\htdocs\broad_front\resources\views/components/badge.blade.php ENDPATH**/ ?>