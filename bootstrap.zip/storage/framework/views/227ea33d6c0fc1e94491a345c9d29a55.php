<?php $__env->startSection('content'); ?>
<div class="container pb-5 mb-5">
    <div class="row justify-content-center my-industry-div">
        <div class="col-lg-11 mb-4">
            <h2 class="profile-title">Select your Industry</h2>
        </div>
        <div class="col-lg-11 mb-5 mt-4 text-center">
            <img class="m-auto" width="288" src="<?php echo e('/images/start-step.png'); ?>" alt="start step">
        </div>
        <form method="POST" action="<?php echo e(route('store-profile', ['step' => 2])); ?>">
            <?php echo csrf_field(); ?>
            <div class="grid-4 col-lg-11 mb-4">
                <?php if(count($industries) > 0): ?>
                    <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="checkbox-card">
                          
                            <input type="radio" name="industry" id="<?php echo e($industry->id); ?>" class="checkbox" value="<?php echo e($industry->id); ?>"    <?php echo e((session('step2')['industry'] ?? old('industry')) == $industry->id ? 'checked' : ''); ?>   required>
                            <label for="<?php echo e($industry->id); ?>" class="card">
                                <img class="icon" src="/images/<?php echo e($industry->icon_img); ?>" alt="cinema-icon" id="cinema-icon">
                                <img class="separator" src="<?php echo e('/images/separator-line.svg'); ?>" alt="separator-line"
                                    id="separator-line">
                                <div>
                                    <div class="title"><?php echo e($industry->name); ?></div>
                                </div>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="col-lg-11 mt-5">
                <div class="d-flex justify-content-center gap-3">

                    <a type="button" class="back-rounded-btn text-decoration-none" href="/profile/step/1">
                        <img src="/images/left-arrow.svg" style=" transform: scaleX(-1); filter: brightness(0)"
                            alt="left arraow">
                        <?php echo e(__('Back')); ?>

                    </a>
                    <button type="submit" class="continue-btn">
                        <?php echo e(__('Continue')); ?>

                        <img src="/images/left-arrow.svg" alt="left arraow">
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile_without_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\broad_front\resources\views/profile/my_industry.blade.php ENDPATH**/ ?>