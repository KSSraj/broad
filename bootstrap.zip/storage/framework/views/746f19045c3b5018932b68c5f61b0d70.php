<!DOCTYPE html>
<html>
<head>
    <title>Your OTP Code</title>
</head>
<body>
    <h1>Hello!</h1>
    <p>Your One-Time Password (OTP) is:</p>
    <h2><?php echo e($otp); ?></h2>
    <p>This OTP is valid for 10 minutes. Please do not share it with anyone.</p>
    <p>Thank you!</p>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\broad_front\resources\views/emails/send_otp.blade.php ENDPATH**/ ?>