<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="mt-5 text-center">

                     <img src="/images/success.png" alt="success" width="479.36px">
                    <h1 class="display-text">Let’s grab your Opportunity </h1>
                    <p>Welcome on the BroadStage Networks</p>
                    <a class="continue-button-general m-auto text-center" href="/profile/step/2"> Set up your Profile</a>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.signup_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\broad_front\resources\views/auth/signup_success.blade.php ENDPATH**/ ?>